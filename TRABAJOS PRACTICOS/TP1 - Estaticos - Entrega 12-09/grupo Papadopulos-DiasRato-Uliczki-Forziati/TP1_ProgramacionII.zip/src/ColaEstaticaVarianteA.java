/**
 * TDA Cola - Implementacion estatica, VARIANTE A (lineal simple).
 */
public class ColaEstaticaVarianteA implements Cola {

    private int[] datos;
    private int inicio;     // indice del primer elemento
    private int fin;        // indice del proximo lugar libre
    private int cantidad;   // cuantos elementos hay actualmente
    private int capacidad;

    // crear() -> Cola
    public ColaEstaticaVarianteA(int capacidad) {
        this.capacidad = capacidad;
        this.datos = new int[capacidad];
        this.inicio = 0;
        this.fin = 0;
        this.cantidad = 0;
    }

    // esVacia(c) -> boolean
    @Override
    public boolean esVacia() {
        return cantidad == 0;
    }

    // esLlena(c) -> boolean
    @Override
    public boolean esLlena() {
        return fin == capacidad;
    }

    // encolar(c, x) -> Cola
    // Complejidad: O(1) -> solo escribe en datos[fin] y suma 1
    @Override
    public void encolar(int x) {
        if (esLlena()) {
            throw new RuntimeException("Cola llena");
        }
        datos[fin] = x;
        fin++;              // avanza hacia adelante mientras haya elementos
        cantidad++;
    }

    // desencolar(c) -> Cola
    // Complejidad: O(1) -> solo lee datos[inicio] y suma 1
    @Override
    public int desencolar() {
        if (esVacia()) {
            throw new RuntimeException("Cola vacia");
        }
        int valor = datos[inicio];
        inicio++;            // avanza hacia adelante mientras haya elementos
        cantidad--;

        // Si la cola queda completamente vacia, reiniciamos los indices.
        // Sigue siendo una cola lineal: no reutiliza huecos mientras tenga elementos.
        if (cantidad == 0) {
            inicio = 0;
            fin = 0;
        }

        return valor;
    }

    // primero(c) -> elemento
    // Complejidad: O(1)
    @Override
    public int primero() {
        if (esVacia()) {
            throw new RuntimeException("Cola vacia");
        }
        return datos[inicio];
    }

    // utilidad para pruebas, no es parte de la especificacion
    public int tamanio() {
        return cantidad;
    }
}

public interface Pila {

    // apilar(p, x) -> Pila
    // post: x queda en el tope de p
    void apilar(int x);

    // desapilar(p) -> Pila
    // pre:  p no esta vacia
    // post: se elimina el elemento del tope de p
    void desapilar();

    // tope(p) -> elemento
    // pre:  p no esta vacia
    // post: devuelve el elemento del tope sin eliminarlo
    int tope();

    // esVacia(p) -> boolean
    boolean esVacia();

    // esLlena(p) -> boolean (auxiliar, por ser implementacion de tamano fijo)
    boolean esLlena();
}
/**
 * TDA ColaConPrioridad - Implementacion estatica, VARIANTE B (ordenada).
 */
public class ColaPrioridadEstaticaVarianteB implements ColaConPrioridad {
    private String[] valores;
    private int[] prioridades;
    private int cantidad;
    private int capacidad;

    // crear() -> CCP
    public ColaPrioridadEstaticaVarianteB(int capacidad) {
        this.capacidad = capacidad;
        this.valores = new String[capacidad];
        this.prioridades = new int[capacidad];
        this.cantidad = 0;
    }

    @Override
    public boolean esVacia() {
        return cantidad == 0;
    }

    @Override
    public boolean esLlena() {
        return cantidad == capacidad;
    }

    @Override
    public int tamanio() {
        return cantidad;
    }

    private int indiceInsercion(int prioridad) {
        int i = 0;
        while (i < cantidad && prioridades[i] < prioridad) {
            i++;
        }
        return i;
    }

    // insertar(c, x, prioridad) -> CCP
    // Complejidad: O(n)
    @Override
    public void insertar(String x, int prioridad) {
        if (esLlena()) {
            throw new RuntimeException("Cola de prioridad llena");
        }
        int pos = indiceInsercion(prioridad);
        for (int i = cantidad; i > pos; i--) {
            valores[i] = valores[i - 1];
            prioridades[i] = prioridades[i - 1];
        }
        valores[pos] = x;
        prioridades[pos] = prioridad;
        cantidad++;
    }

    // verMax(c) -> elemento
    // Complejidad: O(1)
    @Override
    public String verMax() {
        if (esVacia()) {
            throw new RuntimeException("Vacia");
        }
        return valores[cantidad - 1];
    }

    // prioridadMax(c) -> entero
    // Complejidad: O(1)
    @Override
    public int prioridadMax() {
        if (esVacia()) {
            throw new RuntimeException("Vacia");
        }
        return prioridades[cantidad - 1];
    }

    // extraerMax(c) -> CCP
    // Complejidad: O(1) 
    @Override
    public String extraerMax() {
        if (esVacia()) {
            throw new RuntimeException("Vacia");
        }
        cantidad--;
        return valores[cantidad];
    }
}

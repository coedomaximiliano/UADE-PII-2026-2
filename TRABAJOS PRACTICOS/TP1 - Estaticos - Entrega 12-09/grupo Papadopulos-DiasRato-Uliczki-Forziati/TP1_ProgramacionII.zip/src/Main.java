import java.util.function.IntFunction;

/**
 *   - Prueba basica de PilaEstaticaVarianteA / VarianteB      (Parte 1)
 *   - Metodos de utilizacion del TDA Cola + demo              (Parte 2)
 *   - Metodos de utilizacion del TDA ColaConPrioridad + demo  (Parte 3)
 */
public class Main {

    public static void main(String[] args) {
        pruebaPila();
        System.out.println();
        pruebaUtilizacionPila();
        System.out.println();
        pruebaUtilizacionCola();
        System.out.println();
        pruebaUtilizacionColaPrioridad();
    }

    // ================================================================
    // PARTE 1 - Prueba basica de PilaEstaticaVarianteA / VarianteB
    // ================================================================
    private static void pruebaPila() {
        System.out.println("========================================");
        System.out.println("PARTE 1 - PilaEstaticaVarianteA / VarianteB");
        System.out.println("========================================");

        System.out.println("=== Prueba de PilaEstaticaVarianteA ===");
        PilaEstaticaVarianteA pA = new PilaEstaticaVarianteA(5);
        System.out.println(pA.esVacia());  

        pA.apilar(10);
        pA.apilar(20);
        pA.apilar(30);
        System.out.println(pA.tope());      
        System.out.println(pA.esVacia());   
        pA.desapilar();                     
        System.out.println(pA.tope());      
        pA.desapilar();
        pA.desapilar();
        System.out.println(pA.esVacia());  

        System.out.println();
        System.out.println("=== Prueba de PilaEstaticaVarianteB ===");
        PilaEstaticaVarianteB pB = new PilaEstaticaVarianteB(5);
        System.out.println(pB.esVacia());   

        pB.apilar(10);
        pB.apilar(20);
        pB.apilar(30);
        System.out.println(pB.tope());      
        System.out.println(pB.esVacia());   
        pB.desapilar();                     
        System.out.println(pB.tope());      
        pB.desapilar();
        pB.desapilar();
        System.out.println(pB.esVacia());   
    }

    // ================================================================
    // PARTE 1 - Metodos de utilizacion del TDA Pila (1.3)
    // ================================================================

    // Complejidad: O(n)
    public static Pila pasarPila(Pila origen, int capacidad, IntFunction<Pila> fabrica) {
        Pila auxiliar = fabrica.apply(capacidad);
        while (!origen.esVacia()) {
            int x = origen.tope();
            origen.desapilar();
            auxiliar.apilar(x);
        }
        Pila destino = fabrica.apply(capacidad);
        while (!auxiliar.esVacia()) {
            int x = auxiliar.tope();
            auxiliar.desapilar();
            destino.apilar(x);
        }
        return destino; 
    }

    // Complejidad: O(n)
    public static Pila copiarPila(Pila p, int capacidad, IntFunction<Pila> fabrica) {
        if (p.esVacia()) {
            return fabrica.apply(capacidad);
        }
        int x = p.tope();
        p.desapilar();
        Pila copia = copiarPila(p, capacidad, fabrica); 
        p.apilar(x);      
        copia.apilar(x);  
        return copia;
    }

    // Complejidad: O(n)
    public static Pila invertirPila(Pila p, int capacidad, IntFunction<Pila> fabrica) {
        Pila resultado = fabrica.apply(capacidad);
        return invertirPilaAux(p, resultado);
    }

    private static Pila invertirPilaAux(Pila p, Pila resultado) {
        if (p.esVacia()) {
            return resultado;
        }
        int x = p.tope();
        p.desapilar();
        resultado.apilar(x);
        return invertirPilaAux(p, resultado);
    }

    // Complejidad: O(n^2)
    public static boolean masDeUnaOcurrencia(Pila p) {
        if (p.esVacia()) {
            return false;
        }
        int x = p.tope();
        p.desapilar();
        boolean repetido = apareceEnElResto(p, x) || masDeUnaOcurrencia(p);
        p.apilar(x); // restaura
        return repetido;
    }

    private static boolean apareceEnElResto(Pila p, int x) {
        if (p.esVacia()) {
            return false;
        }
        int y = p.tope();
        p.desapilar();
        boolean encontrado = (y == x) || apareceEnElResto(p, x);
        p.apilar(y); 
        return encontrado;
    }

    // Complejidad: O(n)
    public static Pila eliminarImpares(Pila p, int capacidad, IntFunction<Pila> fabrica) {
        if (p.esVacia()) {
            return fabrica.apply(capacidad);
        }
        int x = p.tope();
        p.desapilar();
        Pila resultado = eliminarImpares(p, capacidad, fabrica);
        p.apilar(x); 
        if (x % 2 == 0) {
            resultado.apilar(x);
        }
        return resultado;
    }

    private static void imprimirSinRomper(Pila p, int capacidad, IntFunction<Pila> fabrica) {
        Pila auxiliar = fabrica.apply(capacidad);
        while (!p.esVacia()) {
            int x = p.tope();
            p.desapilar();
            System.out.print(x + " ");
            auxiliar.apilar(x);
        }
        while (!auxiliar.esVacia()) {
            int x = auxiliar.tope();
            auxiliar.desapilar();
            p.apilar(x);
        }
        System.out.println();
    }

    private static void pruebaUtilizacionPila() {
        System.out.println("========================================");
        System.out.println("PARTE 1 - Utilizacion del TDA Pila");
        System.out.println("========================================");

        IntFunction<Pila> fabricaA = PilaEstaticaVarianteA::new;

        Pila p = fabricaA.apply(10);
        for (int v : new int[]{6, 5, 4, 1, 4}) {
            p.apilar(v);
        }

        System.out.print("p original:                ");
        imprimirSinRomper(p, 10, fabricaA);

        Pila copia = copiarPila(p, 10, fabricaA);
        System.out.print("p tras copiarPila:          ");
        imprimirSinRomper(p, 10, fabricaA);
        System.out.print("copia:                      ");
        imprimirSinRomper(copia, 10, fabricaA);

        System.out.println("masDeUnaOcurrencia(p) = " + masDeUnaOcurrencia(p));
        System.out.print("p tras masDeUnaOcurrencia:  ");
        imprimirSinRomper(p, 10, fabricaA);

        Pila pares = eliminarImpares(p, 10, fabricaA);
        System.out.print("p tras eliminarImpares:     ");
        imprimirSinRomper(p, 10, fabricaA);
        System.out.print("pares:                      ");
        imprimirSinRomper(pares, 10, fabricaA);

        Pila invertida = invertirPila(p, 10, fabricaA);
        System.out.print("invertida:                  ");
        imprimirSinRomper(invertida, 10, fabricaA);
        System.out.println("p.esVacia() tras invertirPila = " + p.esVacia());

        Pila origen = fabricaA.apply(5);
        origen.apilar(10);
        origen.apilar(20);
        origen.apilar(30);
        Pila destino = pasarPila(origen, 5, fabricaA);
        System.out.print("pasarPila -> destino:       ");
        imprimirSinRomper(destino, 5, fabricaA);
        System.out.println("origen.esVacia() = " + origen.esVacia());
    }

    // ================================================================
    // PARTE 2 - Metodos de utilizacion del TDA Cola (2.3)
    // ================================================================

    // Complejidad: O(n)
    public static Cola pasarCola(Cola origen, int capacidad, IntFunction<Cola> fabrica) {
        Cola destino = fabrica.apply(capacidad);
        while (!origen.esVacia()) {
            destino.encolar(origen.desencolar());
        }
        return destino;
    }

    // Complejidad: O(n)
    public static Cola invertirColaConPila(Cola c, int capacidadCola,
                                            IntFunction<Cola> fabricaCola,
                                            int capacidadPila) {
        PilaEstaticaVarianteA pila = new PilaEstaticaVarianteA(capacidadPila);
        while (!c.esVacia()) {
            pila.apilar(c.desencolar());
        }
        Cola invertida = fabricaCola.apply(capacidadCola);
        while (!pila.esVacia()) {
            int x = pila.tope();
            pila.desapilar();
            invertida.encolar(x);
        }
        return invertida;
    }

    // Complejidad: O(n)
    public static Cola invertirColaSinPila(Cola c) {
        invertirColaSinPilaAux(c);
        return c;
    }

    private static void invertirColaSinPilaAux(Cola c) {
        if (c.esVacia()) {
            return;
        }
        int x = c.desencolar();
        invertirColaSinPilaAux(c);
        c.encolar(x);
    }

    // Complejidad: O(n1 + n2)
    public static boolean finalCoincide(Cola c1, int capacidad1,
                                         Cola c2, int capacidad2,
                                         int k, IntFunction<Cola> fabrica) {
        Cola ultimosC1 = ultimosK(c1, k, capacidad1, fabrica);
        Cola ultimosC2 = ultimosK(c2, k, capacidad2, fabrica);

        boolean coincide = true;
        while (!ultimosC1.esVacia()) {
            int a = ultimosC1.desencolar();
            int b = ultimosC2.desencolar();
            if (a != b) {
                coincide = false;
            }
        }
        return coincide;
    }

    private static Cola ultimosK(Cola c, int k, int capacidad, IntFunction<Cola> fabrica) {
        Cola restaurar = fabrica.apply(capacidad);
        Cola ventana = fabrica.apply(k);
        int cantidad = 0;

        // Vaciamos c en restaurar y contamos cuantos elementos tiene.
        while (!c.esVacia()) {
            restaurar.encolar(c.desencolar());
            cantidad++;
        }

        int posicion = 0;

        // Restauramos c y guardamos solamente los ultimos k.
        while (!restaurar.esVacia()) {
            int x = restaurar.desencolar();
            c.encolar(x);

            if (posicion >= cantidad - k) {
                ventana.encolar(x);
            }

            posicion++;
        }

        return ventana;
    }

    private static void imprimir(Cola c, int capacidad, IntFunction<Cola> fabrica) {
        Cola auxiliar = fabrica.apply(capacidad);
        while (!c.esVacia()) {
            int x = c.desencolar();
            System.out.print(x + " ");
            auxiliar.encolar(x);
        }
        while (!auxiliar.esVacia()) {
            c.encolar(auxiliar.desencolar());
        }
        System.out.println();
    }

    private static void pruebaUtilizacionCola() {
        System.out.println("========================================");
        System.out.println("PARTE 2 - Utilizacion del TDA Cola");
        System.out.println("========================================");

        IntFunction<Cola> fabricaB = ColaEstaticaVarianteB::new;

        System.out.println("=== pasarCola ===");
        Cola origen = fabricaB.apply(5);
        origen.encolar(1);
        origen.encolar(2);
        origen.encolar(3);
        Cola destino = pasarCola(origen, 5, fabricaB);
        System.out.print("destino: ");
        imprimir(destino, 5, fabricaB);
        System.out.println("origen.esVacia() = " + origen.esVacia());

        System.out.println("\n=== invertirColaConPila ===");
        Cola c = fabricaB.apply(5);
        c.encolar(10);
        c.encolar(20);
        c.encolar(30);
        c.encolar(40);
        Cola invertida = invertirColaConPila(c, 5, fabricaB, 5);
        System.out.print("invertida: ");
        imprimir(invertida, 5, fabricaB);

        System.out.println("\n=== invertirColaSinPila ===");
        Cola c2 = fabricaB.apply(5);
        c2.encolar(1);
        c2.encolar(2);
        c2.encolar(3);
        c2.encolar(4);
        invertirColaSinPila(c2);
        System.out.print("c2 invertida: ");
        imprimir(c2, 5, fabricaB);

        System.out.println("\n=== finalCoincide ===");
        Cola a = fabricaB.apply(6);
        for (int v : new int[]{1, 2, 3, 8, 9}) a.encolar(v);
        Cola b = fabricaB.apply(6);
        for (int v : new int[]{5, 5, 5, 8, 9}) b.encolar(v);
        System.out.println("finalCoincide(a,b,2) (deberia ser true)  = "
                + finalCoincide(a, 6, b, 6, 2, fabricaB));
        System.out.println("finalCoincide(a,b,3) (deberia ser false) = "
                + finalCoincide(a, 6, b, 6, 3, fabricaB));
        System.out.print("a intacta: ");
        imprimir(a, 6, fabricaB);
        System.out.print("b intacta: ");
        imprimir(b, 6, fabricaB);
    }

    // ================================================================
    // PARTE 3 - Metodos de utilizacion del TDA ColaConPrioridad (3.3)
    // ================================================================

    public static ColaConPrioridad combinar(ColaConPrioridad cp1, ColaConPrioridad cp2,
                                             IntFunction<ColaConPrioridad> fabrica) {
        int capacidad = cp1.tamanio() + cp2.tamanio();
        ColaConPrioridad combinada = fabrica.apply(capacidad);

        while (!cp1.esVacia() && !cp2.esVacia()) {
            if (cp1.prioridadMax() >= cp2.prioridadMax()) {
                String x = cp1.verMax();
                int p = cp1.prioridadMax();
                cp1.extraerMax();
                combinada.insertar(x, p);
            } else {
                String x = cp2.verMax();
                int p = cp2.prioridadMax();
                cp2.extraerMax();
                combinada.insertar(x, p);
            }
        }
        while (!cp1.esVacia()) {
            String x = cp1.verMax();
            int p = cp1.prioridadMax();
            cp1.extraerMax();
            combinada.insertar(x, p);
        }
        while (!cp2.esVacia()) {
            String x = cp2.verMax();
            int p = cp2.prioridadMax();
            cp2.extraerMax();
            combinada.insertar(x, p);
        }
        return combinada;
    }

    public static Cola invertirColaConColaPrioridad(Cola c, int capacidadCola,
                                                      IntFunction<Cola> fabricaCola,
                                                      int capacidadCCP,
                                                      IntFunction<ColaConPrioridad> fabricaCCP) {
        ColaConPrioridad ccp = fabricaCCP.apply(capacidadCCP);
        int prioridad = 1;
        while (!c.esVacia()) {
            int x = c.desencolar();
            ccp.insertar(String.valueOf(x), prioridad);
            prioridad++;
        }
        Cola invertida = fabricaCola.apply(capacidadCola);
        while (!ccp.esVacia()) {
            String valor = ccp.extraerMax();
            invertida.encolar(Integer.parseInt(valor));
        }
        return invertida;
    }

    
    public static int sumarValoresPrioridadPar(ColaConPrioridad cp,
                                                ColaConPrioridad auxiliar) {
        int suma = 0;

        // Recorremos cp usando solamente operaciones del TDA ColaConPrioridad.
        while (!cp.esVacia()) {
            String valorStr = cp.verMax();
            int prioridad = cp.prioridadMax();
            cp.extraerMax();

            int valor = Integer.parseInt(valorStr);
            if (prioridad % 2 == 0) {
                suma += valor;
            }

            auxiliar.insertar(valorStr, prioridad);
        }

        // Restauramos cp para que quede con el mismo contenido y orden de extraccion.
        while (!auxiliar.esVacia()) {
            String valorStr = auxiliar.verMax();
            int prioridad = auxiliar.prioridadMax();
            auxiliar.extraerMax();
            cp.insertar(valorStr, prioridad);
        }

        return suma;
    }

    private static void pruebaUtilizacionColaPrioridad() {
        System.out.println("========================================");
        System.out.println("PARTE 3 - Utilizacion del TDA ColaConPrioridad");
        System.out.println("========================================");

        IntFunction<ColaConPrioridad> fabricaCCP_B = ColaPrioridadEstaticaVarianteB::new;
        IntFunction<Cola> fabricaCola = ColaEstaticaVarianteB::new;

        System.out.println("=== combinar ===");
        ColaConPrioridad cp1 = fabricaCCP_B.apply(5);
        cp1.insertar("Backup", 1);
        cp1.insertar("Incendio", 5);
        cp1.insertar("Email", 2);

        ColaConPrioridad cp2 = fabricaCCP_B.apply(5);
        cp2.insertar("Reunion", 5); 
        cp2.insertar("Deploy", 4);

        ColaConPrioridad combinada = combinar(cp1, cp2, fabricaCCP_B);
        System.out.println("cp1.esVacia() = " + cp1.esVacia() + " | cp2.esVacia() = " + cp2.esVacia());
        System.out.print("orden de extraccion de la combinada: ");
        while (!combinada.esVacia()) {
            System.out.print(combinada.extraerMax() + " ");
        }
        System.out.println("\n(esperado: Incendio, Reunion, Deploy, Email, Backup)");

        System.out.println("\n=== invertirColaConColaPrioridad ===");
        Cola c = fabricaCola.apply(5);
        c.encolar(1);
        c.encolar(2);
        c.encolar(3);
        c.encolar(4);
        Cola invertida = invertirColaConColaPrioridad(c, 5, fabricaCola, 5, fabricaCCP_B);
        System.out.print("invertida: ");
        while (!invertida.esVacia()) {
            System.out.print(invertida.desencolar() + " ");
        }
        System.out.println("(esperado: 4 3 2 1)");

        System.out.println("\n=== sumarValoresPrioridadPar ===");
        ColaConPrioridad cp = fabricaCCP_B.apply(5);
        cp.insertar("10", 1);
        cp.insertar("20", 2);
        cp.insertar("30", 4);
        cp.insertar("5", 3);
        ColaConPrioridad auxiliar = fabricaCCP_B.apply(cp.tamanio());
        int suma = sumarValoresPrioridadPar(cp, auxiliar);
        System.out.println("suma (esperado 50) = " + suma);
        System.out.println("cp.tamanio() tras la llamada (deberia seguir siendo 4) = " + cp.tamanio());
        System.out.print("cp tal cual queda (orden de extraccion): ");
        while (!cp.esVacia()) {
            System.out.print(cp.extraerMax() + " ");
        }
        System.out.println();
    }
}
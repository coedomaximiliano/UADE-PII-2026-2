/**
 * TDA ColaConPrioridad - Implementacion estatica, VARIANTE A (desordenada).
 */
public class ColaPrioridadEstaticaVarianteA implements ColaConPrioridad {
    private String[] valores;
    private int[] prioridades;
    private int cantidad;
    private int capacidad;

    // crear() -> CCP
    public ColaPrioridadEstaticaVarianteA(int capacidad) {
        this.capacidad = capacidad;
        this.valores = new String[capacidad];
        this.prioridades = new int[capacidad];
        this.cantidad = 0;
    }

    @Override
    public boolean esVacia() {
        return cantidad == 0;
    }

    @Override
    public boolean esLlena() {
        return cantidad == capacidad;
    }

    @Override
    public int tamanio() {
        return cantidad;
    }

    // insertar(c, x, prioridad) -> CCP
    // Complejidad: O(1)
    @Override
    public void insertar(String x, int prioridad) {
        if (esLlena()) {
            throw new RuntimeException("Cola de prioridad llena");
        }
        valores[cantidad] = x;
        prioridades[cantidad] = prioridad;
        cantidad++;
    }

    private int indiceMax() {
        int idxMax = 0;
        for (int i = 1; i < cantidad; i++) {
            if (prioridades[i] > prioridades[idxMax]) {
                idxMax = i;
            }
        }
        return idxMax;
    }

    // verMax(c) -> elemento
    // Complejidad: O(n)
    @Override
    public String verMax() {
        if (esVacia()) {
            throw new RuntimeException("Vacia");
        }
        return valores[indiceMax()];
    }

    // prioridadMax(c) -> entero
    // Complejidad: O(n)
    @Override
    public int prioridadMax() {
        if (esVacia()) {
            throw new RuntimeException("Vacia");
        }
        return prioridades[indiceMax()];
    }

    // extraerMax(c) -> CCP
    // Complejidad: O(n)
    @Override
    public String extraerMax() {
        if (esVacia()) {
            throw new RuntimeException("Vacia");
        }
        int idx = indiceMax();
        String valor = valores[idx];
        for (int i = idx; i < cantidad - 1; i++) {
            valores[i] = valores[i + 1];
            prioridades[i] = prioridades[i + 1];
        }
        cantidad--;
        return valor;
    }
}

public interface ColaConPrioridad {

    // insertar(c, x, prioridad) -> CCP
    // pre:  c no esta llena
    // post: x queda insertado en c, asociado a prioridad
    void insertar(String x, int prioridad);

    // extraerMax(c) -> CCP
    // pre:  c no esta vacia
    // post: se elimina de c el elemento de mayor prioridad
    // (devuelve directamente el valor eliminado, igual que en
    // ColaPrioridadEstatica de la Clase 3)
    String extraerMax();

    // verMax(c) -> elemento
    // pre:  c no esta vacia
    // post: devuelve el elemento de mayor prioridad, sin eliminarlo
    String verMax();

    // prioridadMax(c) -> entero   (EXTENSION al TDA de la Clase 3,
    // necesaria para poder trasladar elementos entre colas de
    // prioridad conservando su prioridad original: ver combinar()
    // e invertirColaConColaPrioridad() en la utilizacion)
    // pre:  c no esta vacia
    // post: devuelve la prioridad del elemento de mayor prioridad
    int prioridadMax();

    // esVacia(c) -> boolean
    boolean esVacia();

    // esLlena(c) -> boolean
    boolean esLlena();

    // tamanio(c) -> entero
    int tamanio();
}

public class PilaEstaticaVarianteB implements Pila {

    private int[] datos;
    private int cantidad;  
    private int capacidad;

    // crear() -> Pila
    // post: devuelve una pila vacia
    public PilaEstaticaVarianteB(int capacidad) {
        this.capacidad = capacidad;
        this.datos = new int[capacidad];
        this.cantidad = 0;
    }

    // esVacia(p) -> boolean
    // post: devuelve true si p no tiene elementos
    public boolean esVacia() {
        return cantidad == 0;
    }

    public boolean esLlena() {
        return cantidad == capacidad;
    }

    // apilar(p, x) -> Pila
    // post: x queda en el tope de p (posicion 0)
    // Complejidad: O(n)
    public void apilar(int x) {
        if (esLlena()) {
            throw new RuntimeException("Pila llena");
        }
        for (int i = cantidad; i > 0; i--) {
            datos[i] = datos[i - 1];
        }
        datos[0] = x;
        cantidad++;
    }

    // desapilar(p) -> Pila
    // pre:  p no esta vacia
    // post: se elimina el elemento del tope de p (posicion 0)
    // Complejidad: O(n)
    public void desapilar() {
        if (esVacia()) {
            throw new RuntimeException("Pila vacia");
        }
        for (int i = 0; i < cantidad - 1; i++) {
            datos[i] = datos[i + 1];
        }
        cantidad--;
    }

    // tope(p) -> elemento
    // pre:  p no esta vacia
    // post: devuelve el elemento del tope sin eliminarlo
    // Complejidad: O(1)
    public int tope() {
        if (esVacia()) {
            throw new RuntimeException("Pila vacia");
        }
        return datos[0];
    }
}
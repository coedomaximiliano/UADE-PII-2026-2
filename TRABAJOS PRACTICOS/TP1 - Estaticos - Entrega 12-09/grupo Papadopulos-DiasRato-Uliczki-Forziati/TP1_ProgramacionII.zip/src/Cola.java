public interface Cola {

    // encolar(c, x) -> Cola
    // post: x queda al final de c
    void encolar(int x);

    // desencolar(c) -> Cola
    // pre:  c no esta vacia
    // post: se quita el elemento del frente de c
    int desencolar();

    // frente(c) -> elemento   (en el codigo lo llamamos primero(),
    // igual que en las slides de la Clase 2)
    // pre:  c no esta vacia
    // post: devuelve el elemento del frente de c, sin sacarlo
    int primero();

    // esVacia(c) -> boolean
    boolean esVacia();

    // esLlena(c) -> boolean (auxiliar, por ser implementacion de tamano fijo)
    boolean esLlena();
}

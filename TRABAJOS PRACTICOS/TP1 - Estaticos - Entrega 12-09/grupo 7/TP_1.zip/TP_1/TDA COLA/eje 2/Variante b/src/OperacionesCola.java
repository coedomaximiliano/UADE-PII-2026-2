public class OperacionesCola {

    // PUNTO 6


    public static ColaTDA pasarCola(ColaTDA origen) {

        ColaTDA nueva = new ColaTDA(origen.getCapacidad());

        while (!origen.esVacia()) {

            int elemento = origen.desencolar();

            nueva.encolar(elemento);
        }

        return nueva;
    }


    // PUNTO 7


    public static ColaTDA invertirColaConPila(ColaTDA c) {

        PilaTDA pila = new PilaTDA(c.getCapacidad());

        ColaTDA nueva = new ColaTDA(c.getCapacidad());


        // Pasamos la cola a la pila

        while (!c.esVacia()) {

            int elemento = c.desencolar();

            pila.push(elemento);
        }




        while (!pila.esVacia()) {

            int elemento = pila.pop();

            nueva.encolar(elemento);
        }


        return nueva;
    }


    // PUNTO 8

    public static ColaTDA invertirColaSinPila(ColaTDA c) {

        if (c.esVacia()) {

            return new ColaTDA(c.getCapacidad());
        }

        int elemento = c.desencolar();

        ColaTDA invertida = invertirColaSinPila(c);

        invertida.encolar(elemento);

        return invertida;
    }


    // PUNTO 9


    public static boolean finalCoincide(
            ColaTDA c1,
            ColaTDA c2,
            int k) {


        if (k < 0) {
            return false;
        }


        int cantidad1 = contarYRestaurar(c1);

        int cantidad2 = contarYRestaurar(c2);




        if (k > cantidad1 || k > cantidad2) {
            return false;
        }



        for (int i = 0; i < cantidad1 - k; i++) {

            int elemento = c1.desencolar();

            c1.encolar(elemento);
        }


        for (int i = 0; i < cantidad2 - k; i++) {

            int elemento = c2.desencolar();

            c2.encolar(elemento);
        }


        boolean resultado = true;




        for (int i = 0; i < k; i++) {

            int elemento1 = c1.desencolar();

            int elemento2 = c2.desencolar();


            if (elemento1 != elemento2) {
                resultado = false;
            }




            c1.encolar(elemento1);

            c2.encolar(elemento2);
        }



        for (int i = 0; i < cantidad1 - k; i++) {

            int elemento = c1.desencolar();

            c1.encolar(elemento);
        }


        for (int i = 0; i < cantidad2 - k; i++) {

            int elemento = c2.desencolar();

            c2.encolar(elemento);
        }


        return resultado;
    }


    private static int contarYRestaurar(ColaTDA c) {

        if (c.esVacia()) {
            return 0;
        }

        int elemento = c.desencolar();

        int cantidad = contarYRestaurar(c);

        c.encolar(elemento);

        return cantidad + 1;
    }
}
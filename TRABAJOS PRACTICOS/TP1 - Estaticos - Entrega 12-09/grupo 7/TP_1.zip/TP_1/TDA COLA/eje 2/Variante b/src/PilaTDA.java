public class PilaTDA {

    private int[] datos;
    private int tope;
    private int capacidad;

    public PilaTDA(int capacidad) {
        this.capacidad = capacidad;
        this.datos = new int[capacidad];
        this.tope = 0;
    }

    public void push(int elemento) {

        if (esLlena()) {
            throw new RuntimeException("Pila llena");
        }

        datos[tope] = elemento;
        tope++;
    }

    public int pop() {

        if (esVacia()) {
            throw new RuntimeException("Pila vacía");
        }

        tope--;

        return datos[tope];
    }

    public boolean esVacia() {
        return tope == 0;
    }

    public boolean esLlena() {
        return tope == capacidad;
    }
}
public class ColaTDA {

    private int[] datos;
    private int inicio;
    private int cantidad;
    private int capacidad;

    public ColaTDA(int capacidad) {
        this.capacidad = capacidad;
        this.datos = new int[capacidad];
        this.inicio = 0;
        this.cantidad = 0;
    }

    public void encolar(int elemento) {

        if (esLlena()) {
            throw new RuntimeException("Cola llena");
        }

        int posicion = (inicio + cantidad) % capacidad;

        datos[posicion] = elemento;

        cantidad++;
    }

    public int desencolar() {

        if (esVacia()) {
            throw new RuntimeException("Cola vacía");
        }

        int elemento = datos[inicio];

        inicio = (inicio + 1) % capacidad;

        cantidad--;

        return elemento;
    }

    public int Frente() {

        if (esVacia()) {
            throw new RuntimeException("Cola vacía");
        }

        return datos[inicio];
    }

    public boolean esVacia() {
        return cantidad == 0;
    }

    public boolean esLlena() {
        return cantidad == capacidad;
    }

    public int getCapacidad() {
        return capacidad;
    }
}
public class Main {

    public static void main(String[] args) {


        ColaTDA cola = new ColaTDA(50);

        System.out.println("¿Está vacía?: " + cola.esVacia());
        System.out.println("¿Está llena?: " + cola.esLlena());


        cola.encolar(10);
        cola.encolar(20);
        cola.encolar(30);

        System.out.println("Frente: " + cola.Frente());


        System.out.println("Desencolado: " + cola.desencolar());

        System.out.println("Nuevo frente: " + cola.Frente());

        System.out.println("¿Está vacía?: " + cola.esVacia());
        System.out.println("¿Está llena?: " + cola.esLlena());




                // =========================================
                // PUNTO 6 - pasarCola
                // =========================================

                ColaTDA cola1 = new ColaTDA(10);

                cola1.encolar(10);
                cola1.encolar(20);
                cola1.encolar(30);
                cola1.encolar(40);

                ColaTDA copia = OperacionesCola.pasarCola(cola1);

                System.out.println("Punto 6:");
                System.out.println("Cola original vacía: " + cola1.esVacia());

                while (!copia.esVacia()) {
                    System.out.println(copia.desencolar());
                }


                // =========================================
                // PUNTO 7 - invertirColaConPila
                // =========================================

                ColaTDA cola2 = new ColaTDA(10);

                cola2.encolar(10);
                cola2.encolar(20);
                cola2.encolar(30);
                cola2.encolar(40);

                ColaTDA invertida1 =
                        OperacionesCola.invertirColaConPila(cola2);

                System.out.println("\nPunto 7:");

                while (!invertida1.esVacia()) {
                    System.out.println(invertida1.desencolar());
                }


                // =========================================
                // PUNTO 8 - invertirColaSinPila
                // =========================================

                ColaTDA cola3 = new ColaTDA(10);

                cola3.encolar(10);
                cola3.encolar(20);
                cola3.encolar(30);
                cola3.encolar(40);

                ColaTDA invertida2 =
                        OperacionesCola.invertirColaSinPila(cola3);

                System.out.println("\nPunto 8:");

                while (!invertida2.esVacia()) {
                    System.out.println(invertida2.desencolar());
                }


                // =========================================
                // PUNTO 9 - finalCoincide
                // =========================================

                ColaTDA c1 = new ColaTDA(10);

                c1.encolar(10);
                c1.encolar(20);
                c1.encolar(30);
                c1.encolar(40);


                ColaTDA c2 = new ColaTDA(10);

                c2.encolar(50);
                c2.encolar(30);
                c2.encolar(40);


                boolean resultado =
                        OperacionesCola.finalCoincide(c1, c2, 2);


                System.out.println("\nPunto 9:");

                System.out.println(
                        "¿Los últimos 2 coinciden?: " + resultado
                );



                System.out.println("\nC1 después de comparar:");

                while (!c1.esVacia()) {
                    System.out.println(c1.desencolar());
                }


                System.out.println("\nC2 después de comparar:");

                while (!c2.esVacia()) {
                    System.out.println(c2.desencolar());
                }
            }
        }


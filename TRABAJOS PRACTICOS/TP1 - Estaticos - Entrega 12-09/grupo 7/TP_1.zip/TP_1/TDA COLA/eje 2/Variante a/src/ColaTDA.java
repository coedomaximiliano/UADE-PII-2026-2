public class ColaTDA {

    private int[] datos;
    private int inicio;
    private int cantidad;
    private int capacidad;

    public ColaTDA(int capacidad) {
        this.capacidad = capacidad;
        this.datos = new int[capacidad];
        this.inicio = 0;
        this.cantidad = 0;
    }

    public void encolar(int x) {

        if (esLlena()) {
            throw new RuntimeException("Cola llena");
        }

        datos[inicio + cantidad] = x;
        cantidad = cantidad + 1;
    }

    public int desencolar() {

        if (esVacia()) {
            throw new RuntimeException("Cola vacía");
        }

        int elemento = datos[inicio];

        inicio = inicio + 1;
        cantidad = cantidad - 1;

        return elemento;
    }

    public boolean esVacia() {
        return cantidad == 0;
    }

    public boolean esLlena() {
        return cantidad == capacidad;
    }
}
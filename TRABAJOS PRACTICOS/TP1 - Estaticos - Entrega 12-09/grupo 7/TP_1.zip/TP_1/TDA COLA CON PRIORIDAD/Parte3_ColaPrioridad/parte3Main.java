public class parte3Main {

    public static void main(String[] args) {
        probarVarianteDesordenada();
        probarVarianteOrdenada();
        probarCombinar();
        probarInvertirCola();
        probarSumaPrioridadesPares();
    }

    private static void probarVarianteDesordenada() {
        ColaPrioridad cp = new ColaPrioridadDesordenada(5);
        cp.insertar(10, 5);
        cp.insertar(20, 5);
        cp.insertar(30, 2);

        System.out.println("Desordenada: "
                + cp.extraerMax() + " "
                + cp.extraerMax() + " "
                + cp.extraerMax());
    }

    private static void probarVarianteOrdenada() {
        ColaPrioridad cp = new ColaPrioridadOrdenada(5);
        cp.insertar(10, 5);
        cp.insertar(20, 5);
        cp.insertar(30, 2);

        System.out.println("Ordenada: "
                + cp.extraerMax() + " "
                + cp.extraerMax() + " "
                + cp.extraerMax());
    }

    private static void probarCombinar() {
        ColaPrioridad cp1 = new ColaPrioridadDesordenada(4);
        ColaPrioridad cp2 = new ColaPrioridadOrdenada(4);

        cp1.insertar(10, 5);
        cp1.insertar(11, 5);
        cp1.insertar(12, 1);

        cp2.insertar(20, 5);
        cp2.insertar(21, 2);

        ColaPrioridad combinada =
                UtilizacionColaPrioridad.combinar(cp1, cp2);

        System.out.print("Combinada: ");
        while (!combinada.esVacia()) {
            System.out.print(combinada.extraerMax() + " ");
        }
        System.out.println();
    }

    private static void probarInvertirCola() {
        Cola cola = new ColaCircularEstatica(4);
        cola.encolar(1);
        cola.encolar(2);
        cola.encolar(3);
        cola.encolar(4);

        Cola invertida =
                UtilizacionColaPrioridad.invertirColaConColaPrioridad(cola);

        System.out.print("Cola invertida: ");
        while (!invertida.esVacia()) {
            System.out.print(invertida.desencolar() + " ");
        }
        System.out.println();
    }

    private static void probarSumaPrioridadesPares() {
        ColaPrioridad cp = new ColaPrioridadOrdenada(4);
        cp.insertar(5, 1);
        cp.insertar(10, 2);
        cp.insertar(15, 4);
        cp.insertar(20, 3);

        int suma =
                UtilizacionColaPrioridad.sumarValoresPrioridadPar(cp);

        System.out.println("Suma de prioridades pares: " + suma);

        System.out.print("Cola restaurada: ");
        while (!cp.esVacia()) {
            System.out.print(cp.extraerMax() + " ");
        }
        System.out.println();
    }
}

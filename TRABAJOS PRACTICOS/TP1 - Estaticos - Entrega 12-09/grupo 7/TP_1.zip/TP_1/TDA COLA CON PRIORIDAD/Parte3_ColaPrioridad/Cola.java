public interface Cola {

    void encolar(int valor);

    int desencolar();

    int frente();

    boolean esVacia();

    boolean esLlena();

    int tamanio();
}

public class UtilizacionColaPrioridad {

    public static ColaPrioridad combinar(ColaPrioridad cp1,
                                          ColaPrioridad cp2) {
        int capacidad = cp1.tamanio() + cp2.tamanio();
        ColaPrioridad resultado =
                new ColaPrioridadDesordenada(capacidad);

        while (!cp1.esVacia() && !cp2.esVacia()) {
            int prioridad1 = cp1.verPrioridadMax();
            int prioridad2 = cp2.verPrioridadMax();

            if (prioridad1 >= prioridad2) {
                int valor = cp1.extraerMax();
                resultado.insertar(valor, prioridad1);
            } else {
                int valor = cp2.extraerMax();
                resultado.insertar(valor, prioridad2);
            }
        }

        while (!cp1.esVacia()) {
            int prioridad = cp1.verPrioridadMax();
            int valor = cp1.extraerMax();
            resultado.insertar(valor, prioridad);
        }

        while (!cp2.esVacia()) {
            int prioridad = cp2.verPrioridadMax();
            int valor = cp2.extraerMax();
            resultado.insertar(valor, prioridad);
        }

        return resultado;
    }

    public static Cola invertirColaConColaPrioridad(Cola c) {
        int capacidad = c.tamanio();
        ColaPrioridad auxiliar =
                new ColaPrioridadDesordenada(capacidad);
        Cola resultado = new ColaCircularEstatica(capacidad);
        int prioridad = 1;

        while (!c.esVacia()) {
            int valor = c.desencolar();
            auxiliar.insertar(valor, prioridad);
            prioridad++;
        }

        while (!auxiliar.esVacia()) {
            resultado.encolar(auxiliar.extraerMax());
        }

        return resultado;
    }

    public static int sumarValoresPrioridadPar(ColaPrioridad cp) {
        ColaPrioridad auxiliar =
                new ColaPrioridadDesordenada(cp.tamanio());
        int suma = 0;

        while (!cp.esVacia()) {
            int prioridad = cp.verPrioridadMax();
            int valor = cp.extraerMax();

            if (prioridad % 2 == 0) {
                suma = suma + valor;
            }

            auxiliar.insertar(valor, prioridad);
        }

        while (!auxiliar.esVacia()) {
            int prioridad = auxiliar.verPrioridadMax();
            int valor = auxiliar.extraerMax();
            cp.insertar(valor, prioridad);
        }

        return suma;
    }
}

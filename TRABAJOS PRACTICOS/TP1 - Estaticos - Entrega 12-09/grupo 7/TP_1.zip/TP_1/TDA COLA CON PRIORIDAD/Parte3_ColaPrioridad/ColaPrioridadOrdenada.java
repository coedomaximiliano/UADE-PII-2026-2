public class ColaPrioridadOrdenada implements ColaPrioridad {

    private int[] valores;
    private int[] prioridades;
    private int cantidad;
    private int capacidad;

    public ColaPrioridadOrdenada(int capacidad) {
        this.capacidad = capacidad;
        valores = new int[capacidad];
        prioridades = new int[capacidad];
        cantidad = 0;
    }

    public boolean esVacia() {
        return cantidad == 0;
    }

    public boolean esLlena() {
        return cantidad == capacidad;
    }

    public int tamanio() {
        return cantidad;
    }

    public void insertar(int valor, int prioridad) {
        if (esLlena()) {
            throw new RuntimeException("Cola con prioridad llena");
        }

        int i = cantidad - 1;

        while (i >= 0 && prioridades[i] >= prioridad) {
            valores[i + 1] = valores[i];
            prioridades[i + 1] = prioridades[i];
            i--;
        }

        valores[i + 1] = valor;
        prioridades[i + 1] = prioridad;
        cantidad++;
    }

    public int verMax() {
        if (esVacia()) {
            throw new RuntimeException("Cola con prioridad vacia");
        }

        return valores[cantidad - 1];
    }

    public int verPrioridadMax() {
        if (esVacia()) {
            throw new RuntimeException("Cola con prioridad vacia");
        }

        return prioridades[cantidad - 1];
    }

    public int extraerMax() {
        if (esVacia()) {
            throw new RuntimeException("Cola con prioridad vacia");
        }

        cantidad--;
        return valores[cantidad];
    }
}

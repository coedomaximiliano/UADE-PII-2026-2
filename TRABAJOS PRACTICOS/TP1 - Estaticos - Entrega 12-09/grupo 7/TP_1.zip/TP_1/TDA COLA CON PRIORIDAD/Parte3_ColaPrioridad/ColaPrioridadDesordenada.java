public class ColaPrioridadDesordenada implements ColaPrioridad {

    private int[] valores;
    private int[] prioridades;
    private int cantidad;
    private int capacidad;

    public ColaPrioridadDesordenada(int capacidad) {
        this.capacidad = capacidad;
        valores = new int[capacidad];
        prioridades = new int[capacidad];
        cantidad = 0;
    }

    public boolean esVacia() {
        return cantidad == 0;
    }

    public boolean esLlena() {
        return cantidad == capacidad;
    }

    public int tamanio() {
        return cantidad;
    }

    public void insertar(int valor, int prioridad) {
        if (esLlena()) {
            throw new RuntimeException("Cola con prioridad llena");
        }

        valores[cantidad] = valor;
        prioridades[cantidad] = prioridad;
        cantidad++;
    }

    private int indiceMax() {
        int posicionMax = 0;

        for (int i = 1; i < cantidad; i++) {
            if (prioridades[i] > prioridades[posicionMax]) {
                posicionMax = i;
            }
        }

        return posicionMax;
    }

    public int verMax() {
        if (esVacia()) {
            throw new RuntimeException("Cola con prioridad vacia");
        }

        return valores[indiceMax()];
    }

    public int verPrioridadMax() {
        if (esVacia()) {
            throw new RuntimeException("Cola con prioridad vacia");
        }

        return prioridades[indiceMax()];
    }

    public int extraerMax() {
        if (esVacia()) {
            throw new RuntimeException("Cola con prioridad vacia");
        }

        int posicionMax = indiceMax();
        int valorMax = valores[posicionMax];

        for (int i = posicionMax; i < cantidad - 1; i++) {
            valores[i] = valores[i + 1];
            prioridades[i] = prioridades[i + 1];
        }

        cantidad--;
        return valorMax;
    }
}

public class ColaCircularEstatica implements Cola {

    private int[] valores;
    private int frente;
    private int fin;
    private int cantidad;

    public ColaCircularEstatica(int capacidad) {
        valores = new int[capacidad];
        frente = 0;
        fin = 0;
        cantidad = 0;
    }

    public boolean esVacia() {
        return cantidad == 0;
    }

    public boolean esLlena() {
        return cantidad == valores.length;
    }

    public int tamanio() {
        return cantidad;
    }

    public void encolar(int valor) {
        if (esLlena()) {
            throw new RuntimeException("Cola llena");
        }

        valores[fin] = valor;
        fin = (fin + 1) % valores.length;
        cantidad++;
    }

    public int frente() {
        if (esVacia()) {
            throw new RuntimeException("Cola vacia");
        }

        return valores[frente];
    }

    public int desencolar() {
        if (esVacia()) {
            throw new RuntimeException("Cola vacia");
        }

        int valor = valores[frente];
        frente = (frente + 1) % valores.length;
        cantidad--;
        return valor;
    }
}

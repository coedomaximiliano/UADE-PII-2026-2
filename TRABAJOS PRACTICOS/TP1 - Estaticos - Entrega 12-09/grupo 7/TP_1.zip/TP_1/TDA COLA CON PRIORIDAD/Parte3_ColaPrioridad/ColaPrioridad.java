public interface ColaPrioridad {

    void insertar(int valor, int prioridad);

    int extraerMax();

    int verMax();

    int verPrioridadMax();

    boolean esVacia();

    boolean esLlena();

    int tamanio();
}

public class PilaB implements TDAPila {
    private int[] datos;
    private int tope;      // indice del proximo
    private int capacidad;

    public PilaB(int capacidad) {
            this.capacidad = capacidad;
            this.datos = new int[capacidad];
            this.tope = 0;
        }
    public boolean esVacia() {
        return tope == 0;
    }

    public boolean esLlena() {
        return tope == capacidad;
    }
    public void apilar(int x) {
        if (esLlena()) {
            throw new RuntimeException("La pila está Llena, no se puede cargar mas elementos");
        }
        for (int i = tope; i > 0; i--) {
            datos[i] = datos[i - 1];
        }
        datos[0] = x;
        tope++;
    }
    public int desapilar() {
        if (esVacia()) {
            throw new RuntimeException("La pila está vacía, no se puede Desapilar");
        }
        int valor = datos[0];
        for (int i = 0; i < tope - 1; i++) {
            datos[i] = datos[i + 1];
        }
        tope--;
        return valor;
    }
    public int tope() {
        if (esVacia()) {
            throw new RuntimeException("a pila está vacía, no se puede obtener el tope");
        }
        return datos[0];
    }











}



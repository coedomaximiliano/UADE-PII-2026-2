public class Main {

    public static void mostrarPila(TDAPila p) {
        Pila auxiliar = new Pila(100);
        System.out.print("[");
        boolean primero = true;
        while (!p.esVacia()) {
            int elemento = p.desapilar();
            if (!primero) System.out.print(", ");
            System.out.print(elemento);
            primero = false;
            auxiliar.apilar(elemento);
        }
        System.out.println("]");
        while (!auxiliar.esVacia()) {
            p.apilar(auxiliar.desapilar());
        }
    }

    public static TDAPila pasarPila(TDAPila origen) {
        Pila nueva = new Pila(100);
        while (!origen.esVacia()) {
            int elemento = origen.desapilar();
            nueva.apilar(elemento);
        }
        return nueva;
    }

    public static TDAPila copiarPila(TDAPila p) {
        Pila auxiliar = new Pila(100);
        Pila copia = new Pila(100);
        while (!p.esVacia()) {
            int elemento = p.desapilar();
            auxiliar.apilar(elemento);
        }
        while (!auxiliar.esVacia()) {
            int elemento = auxiliar.desapilar();
            p.apilar(elemento);
            copia.apilar(elemento);
        }
        return copia;
    }

    public static TDAPila invertirPila(TDAPila p) {
        Pila nueva = new Pila(100);
        invertirAux(p, nueva);
        return nueva;
    }

    public static void invertirAux(TDAPila p, TDAPila nueva) {
        if (!p.esVacia()) {
            int x = p.desapilar();
            nueva.apilar(x);
            invertirAux(p, nueva);
        }
    }
    public static boolean masDeUnaOcurrencia(TDAPila p) {
        Pila auxiliar = new Pila(100);
        boolean repetido = false;

        while (!p.esVacia()) {
            int x = p.desapilar();
            if (contiene(auxiliar, x)) {
                repetido = true;
            }
            auxiliar.apilar(x);
        }

        while (!auxiliar.esVacia()) {
            p.apilar(auxiliar.desapilar());
        }

        return repetido;
    }

    private static boolean contiene(Pila auxiliar, int x) {
        Pila temp = new Pila(100);
        boolean encontrado = false;

        while (!auxiliar.esVacia()) {
            int y = auxiliar.desapilar();
            if (y == x) {
                encontrado = true;
            }
            temp.apilar(y);
        }

        while (!temp.esVacia()) {
            auxiliar.apilar(temp.desapilar());
        }

        return encontrado;
    }

    public static TDAPila eliminarImpares(TDAPila p) {
        Pila auxiliar = new Pila(100);
        Pila temp = new Pila(100);
        Pila resultado = new Pila(100);

        while (!p.esVacia()) {
            int x = p.desapilar();
            auxiliar.apilar(x);
            if (x % 2 == 0) {
                temp.apilar(x);
            }
        }

        while (!auxiliar.esVacia()) {
            p.apilar(auxiliar.desapilar());
        }

        while (!temp.esVacia()) {
            resultado.apilar(temp.desapilar());
        }

        return resultado;
    }

    public static void main(String[] args) {

        System.out.println("--- pasarPila ---");
        Pila origen = new Pila(10);
        origen.apilar(1);
        origen.apilar(2);
        origen.apilar(3);
        System.out.print("origen antes: ");
        mostrarPila(origen);
        TDAPila nueva = pasarPila(origen);
        System.out.print("origen despues: ");
        mostrarPila(origen);
        System.out.print("nueva: ");
        mostrarPila(nueva);

        System.out.println("--- copiarPila ---");
        Pila p = new Pila(10);
        p.apilar(1);
        p.apilar(2);
        p.apilar(3);
        System.out.print("p antes: ");
        mostrarPila(p);
        TDAPila copia = copiarPila(p);
        System.out.print("p despues: ");
        mostrarPila(p);
        System.out.print("copia: ");
        mostrarPila(copia);

        System.out.println("--- invertirPila ---");
        Pila p2 = new Pila(10);
        p2.apilar(1);
        p2.apilar(2);
        p2.apilar(3);
        System.out.print("p2 antes: ");
        mostrarPila(p2);
        TDAPila invertida = invertirPila(p2);
        System.out.print("p2 despues: ");
        mostrarPila(p2);
        System.out.print("invertida: ");
        mostrarPila(invertida);

        System.out.println("--- masDeUnaOcurrencia ---");
        Pila p5 = new Pila(10);
        p5.apilar(10);
        p5.apilar(20);
        p5.apilar(10);
        System.out.print("p5 antes: ");
        mostrarPila(p5);
        boolean tieneRepetidos = masDeUnaOcurrencia(p5);
        System.out.print("p5 despues: ");
        mostrarPila(p5);
        System.out.println("tiene repetidos: " + tieneRepetidos);

        System.out.println("--- eliminarImpares ---");
        Pila p6 = new Pila(10);
        p6.apilar(2);
        p6.apilar(3);
        p6.apilar(4);
        p6.apilar(5);
        p6.apilar(6);
        System.out.print("p6 antes: ");
        mostrarPila(p6);
        Pila pares = (Pila) eliminarImpares(p6);
        System.out.print("p6 despues: ");
        mostrarPila(p6);
        System.out.print("pares: ");
        mostrarPila(pares);
    }
}
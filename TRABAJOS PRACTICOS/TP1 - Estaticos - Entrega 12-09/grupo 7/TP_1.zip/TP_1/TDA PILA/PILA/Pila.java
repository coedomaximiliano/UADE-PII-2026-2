public class Pila implements TDAPila {
    private int[] datos;
    private int tope;
    int capacidad;

    public Pila( int capacidad) {
        datos = new int[capacidad];
        tope = 0;
        this.capacidad = capacidad;
    }

    public void apilar(int x) {
        // aca lo que hago es sumar 1 a tope pero como tope es -1 se le resta por lo que al principio es 0 y luego 2-1 = 1 y asi.
        if (esLlena()) {
            throw new RuntimeException("La pila está Llena, no se puede cargar mas elementos");
        }
        datos[tope] =  x;
        tope++;
    }

    public int desapilar() {

        if (esVacia()) {
            throw new RuntimeException("La pila está vacía, no se puede Desapilar");
        }
        tope --;
        return datos[tope];
    }

    public int tope() {

        if (esVacia()) {
            throw new RuntimeException("La pila está vacía, no se puede ver el tope");
        }
        return datos[tope-1];
    }

    public boolean esVacia() {
        return tope == 0;
    }

    public boolean esLlena() {
        return tope == capacidad;
    }


}
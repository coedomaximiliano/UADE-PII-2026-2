TDA Pila
Dominio:
Secuencia finita y ordenada de elementos, donde utilizamos LIFO.

Operaciones:
crear () -> Pila
post: devuelve una pila vacia ya que la estoy creando

apilar (p: Pila, x: elemento) -> Pila
pre: p no este llena
post: x queda en el tope de p

desapilar (p: Pila) -> Pila
pre:  p no esta vacia
post: se elimina el elemento del tope de p

tope (p: Pila) -> elemento
pre:  p no esta vacia
post: devuelve el elemento del tope pero sin eliminarlo

esVacia (p: Pila) -> boolean
post: devuelve True (Verdadero) si esta vacia.

esLlena (p: Pila) -> boolean
post: Si esta lleno devuelve True (Verdadero)

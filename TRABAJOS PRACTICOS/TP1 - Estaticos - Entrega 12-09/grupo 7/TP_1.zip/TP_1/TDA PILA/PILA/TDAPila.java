public interface TDAPila {
        void apilar(int x);
        int desapilar();
        int tope();
        boolean esVacia();
        boolean esLlena();
    }


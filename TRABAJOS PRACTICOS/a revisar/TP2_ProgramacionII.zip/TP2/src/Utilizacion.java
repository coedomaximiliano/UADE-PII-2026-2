/**
 * Parte 4: metodos que usan UNICAMENTE las operaciones del TDA Diccionario
 * (interfaz Diccionario). Funcionan igual con DiccionarioDinamico o con
 * DiccionarioEstatico. Ninguno modifica los diccionarios recibidos.
 */
public class Utilizacion {

    // Devuelve un diccionario nuevo con las claves de ambos; si una clave
    // esta en los dos, gana el valor de d2 (definir actualiza si existe)
    public static Diccionario combinarDiccionarios(Diccionario d1, Diccionario d2) {
        Diccionario resultado = new DiccionarioDinamico();
        Object[] claves1 = d1.claves();                       
        for (int i = 0; i < claves1.length; i++) {            
            resultado.definir(claves1[i], d1.obtener(claves1[i]));   
        }
        Object[] claves2 = d2.claves();                       
        for (int i = 0; i < claves2.length; i++) {            
            resultado.definir(claves2[i], d2.obtener(claves2[i]));   
        }
        return resultado;
    }

    // Devuelve un diccionario donde las claves pasan a ser valores y los
    // valores pasan a ser claves (se asume que los valores son unicos).
    public static Diccionario invertir(Diccionario d) {
        Diccionario resultado = new DiccionarioDinamico();
        Object[] claves = d.claves();                         
        for (int i = 0; i < claves.length; i++) {             
            resultado.definir(d.obtener(claves[i]), claves[i]);      
        }
        return resultado;
    }

    // Cuenta cuantos pares tienen valor numerico estrictamente mayor a umbral.
    public static int contarValoresMayoresA(Diccionario d, int umbral) {
        int contador = 0;
        Object[] claves = d.claves();                         
        for (int i = 0; i < claves.length; i++) {             
            int valor = (Integer) d.obtener(claves[i]);       
            if (valor > umbral) {
                contador++;
            }
        }
        return contador;
    }

    // Devuelve una Lista dinamica con las claves (texto) ordenadas alfabeticamente.
    public static ListaDinamica clavesOrdenadas(Diccionario d) {
        Object[] claves = d.claves();                         
        for (int i = 0; i < claves.length - 1; i++) {         
            int posMenor = i;
            for (int j = i + 1; j < claves.length; j++) {
                if (((String) claves[j]).compareToIgnoreCase((String) claves[posMenor]) < 0) {
                    posMenor = j;
                }
            }
            Object aux = claves[i];
            claves[i] = claves[posMenor];
            claves[posMenor] = aux;
        }
        ListaDinamica lista = new ListaDinamica();
        for (int i = 0; i < claves.length; i++) {            
            lista.agregarAlFinal(claves[i]);
        }
        return lista;
    }
}

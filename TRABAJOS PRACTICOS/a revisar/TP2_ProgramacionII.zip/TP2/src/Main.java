public class Main {

    static String claves(Diccionario d) {
        StringBuilder sb = new StringBuilder("[ ");
        for (Object c : d.claves()) sb.append(c).append(" ");
        return sb.append("]").toString();
    }

    public static void main(String[] args) {

        // ---------------- Diccionario dinamico ----------------
        System.out.println("=== crear() ===");
        DiccionarioDinamico agenda = new DiccionarioDinamico();
        System.out.println("esVacio() = " + agenda.esVacio() + " | cantidadClaves() = " + agenda.cantidadClaves());

        System.out.println();
        System.out.println("=== definir ===");
        agenda.definir("juan", "11-2345-6789");
        agenda.definir("maria", "11-9876-5432");
        agenda.definir("pedro", "11-5555-1234");
        agenda.definir("agostina", "11-0000-1111");
        agenda.definir("camila", "11-0000-2222");
        System.out.println(agenda);
        System.out.println("cantidadClaves() = " + agenda.cantidadClaves());

        System.out.println();
        System.out.println("=== misma clave con distinto valor (actualiza, no agrega) ===");
        agenda.definir("juan", "11-0000-3333");
        System.out.println(agenda);
        System.out.println("cantidadClaves() = " + agenda.cantidadClaves() + " (no crecio)");

        System.out.println();
        System.out.println("=== obtener ===");
        System.out.println("obtener(\"juan\") = " + agenda.obtener("juan"));

        System.out.println();
        System.out.println("=== existeClave ===");
        System.out.println("existeClave(\"maria\") = " + agenda.existeClave("maria"));
        System.out.println("existeClave(\"lucas\") = " + agenda.existeClave("lucas"));

        System.out.println();
        System.out.println("=== claves ===");
        System.out.println("claves() = " + claves(agenda) + " (cantidad = " + agenda.claves().length + ")");

        System.out.println();
        System.out.println("=== eliminar ===");
        agenda.eliminar("maria");
        System.out.println(agenda);
        System.out.println("cantidadClaves() = " + agenda.cantidadClaves());

        System.out.println();
        System.out.println("=== esVacio() sobre un diccionario no vacio ===");
        System.out.println("esVacio() = " + agenda.esVacio());

        System.out.println();
        System.out.println("=== precondicion violada: obtener(\"maria\") tras eliminarla ===");
        try {
            agenda.obtener("maria");
        } catch (RuntimeException e) {
            System.out.println("RuntimeException capturada: " + e.getMessage());
        }

        // ---------------- Diccionario estatico ----------------
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("=== crear un diccionario estatico ===");
        DiccionarioEstatico agendaEstatica = new DiccionarioEstatico(5);
        System.out.println("esVacio() = " + agendaEstatica.esVacio() + " | cantidadClaves() = " + agendaEstatica.cantidadClaves());

        System.out.println();
        System.out.println("=== definir ===");
        agendaEstatica.definir("juan", "11-2345-6789");
        agendaEstatica.definir("maria", "11-9876-5432");
        agendaEstatica.definir("roman", "11-1111-1111");
        agendaEstatica.definir("pedro", "11-1111-2222");
        agendaEstatica.definir("valentina", "11-1111-3333");
        System.out.println(agendaEstatica);
        System.out.println("cantidadClaves() = " + agendaEstatica.cantidadClaves());

        System.out.println();
        System.out.println("=== misma clave con distinto valor (actualiza, no agrega) ===");
        agendaEstatica.definir("juan", "11-0000-1111");
        System.out.println(agendaEstatica);
        System.out.println("cantidadClaves() = " + agendaEstatica.cantidadClaves() + " (no crecio)");

        System.out.println();
        System.out.println("=== obtener ===");
        System.out.println("obtener(\"juan\") = " + agendaEstatica.obtener("juan"));

        System.out.println();
        System.out.println("=== existeClave ===");
        System.out.println("existeClave(\"maria\") = " + agendaEstatica.existeClave("maria"));
        System.out.println("existeClave(\"lucas\") = " + agendaEstatica.existeClave("lucas"));

        System.out.println();
        System.out.println("=== claves ===");
        System.out.println("claves() = " + claves(agendaEstatica) + " (cantidad = " + agendaEstatica.claves().length + ")");

        System.out.println();
        System.out.println("=== eliminar ===");
        agendaEstatica.eliminar("maria");
        System.out.println(agendaEstatica);
        System.out.println("cantidadClaves() = " + agendaEstatica.cantidadClaves());

        System.out.println();
        System.out.println("=== esVacio() sobre un diccionario no vacio ===");
        System.out.println("esVacio() = " + agendaEstatica.esVacio());

        System.out.println();
        System.out.println("=== precondicion violada: obtener(\"maria\") tras eliminarla ===");
        try {
            agendaEstatica.obtener("maria");
        } catch (RuntimeException e) {
            System.out.println("RuntimeException capturada: " + e.getMessage());
        }

        // ---------------- Parte 4: utilizacion ----------------
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("---Punto 4---");

        System.out.println("---combinarDiccionarios (dinamico + estatico; en claves repetidas gana el 2do)---");
        System.out.println("Dinamico  " + agenda);
        System.out.println("Estatico  " + agendaEstatica);
        System.out.println("Combinado " + Utilizacion.combinarDiccionarios(agenda, agendaEstatica));

        System.out.println();
        System.out.println("---invertir (valores unicos)---");
        DiccionarioDinamico capitales = new DiccionarioDinamico();
        capitales.definir("Argentina", "Buenos Aires");
        capitales.definir("Chile", "Santiago");
        capitales.definir("Uruguay", "Montevideo");
        System.out.println("Original  " + capitales);
        System.out.println("Invertido " + Utilizacion.invertir(capitales));

        System.out.println();
        System.out.println("---contarValoresMayoresA---");
        DiccionarioEstatico notasAlumnos = new DiccionarioEstatico(5);
        notasAlumnos.definir("Camila", 10);
        notasAlumnos.definir("Sofia", 6);
        notasAlumnos.definir("Martin", 8);
        notasAlumnos.definir("Roberto", 9);
        notasAlumnos.definir("Mario", 2);
        System.out.println("Alumnos con notas mayores a 7: " + Utilizacion.contarValoresMayoresA(notasAlumnos, 7));

        System.out.println();
        System.out.println("---clavesOrdenadas (alfabeticamente, por CLAVE)---");
        System.out.println("Claves originales: " + claves(agendaEstatica));
        System.out.println("Claves ordenadas:  " + Utilizacion.clavesOrdenadas(agendaEstatica));
        System.out.println("Claves ordenadas (dinamico): " + Utilizacion.clavesOrdenadas(agenda));

        System.out.println();
        System.out.println("---los originales no se modificaron---");
        System.out.println(agenda);
        System.out.println(agendaEstatica);

        System.out.println();
        System.out.println("---claves armadas en tiempo de ejecucion (no literales)---");
        DiccionarioEstatico e2 = new DiccionarioEstatico(3);
        e2.definir(new String("ana"), 1);
        System.out.println("existeClave(\"ana\") = " + e2.existeClave("ana") + " (debe ser true)");
    }
}

class NodoLista {
    Object dato;
    NodoLista siguiente;

    NodoLista(Object dato) {
        this.dato = dato;
        this.siguiente = null;
    }
}

public class ListaDinamica {
    private NodoLista primero;
    private NodoLista ultimo;
    private int cantidad;

    public ListaDinamica() {
        primero = null;
        ultimo = null;
        cantidad = 0;
    }

    public void agregarAlFinal(Object x) {
        NodoLista nuevo = new NodoLista(x);
        if (primero == null) {
            primero = nuevo;
        } else {
            ultimo.siguiente = nuevo;
        }
        ultimo = nuevo;
        cantidad++;
    }

    public int tamanio() {
        return cantidad;
    }

    public boolean esVacia() {
        return cantidad == 0;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[ ");
        NodoLista actual = primero;
        while (actual != null) {
            sb.append(actual.dato).append(" ");
            actual = actual.siguiente;
        }
        return sb.append("]").toString();
    }
}

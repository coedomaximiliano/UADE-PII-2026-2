public class DiccionarioEstatico implements Diccionario {

    class Elemento {
        Object clave;
        Object valor;
    }

    private Elemento[] elementos;
    private int cantidad;
    private int capacidad;

    public DiccionarioEstatico(int capacidad) {
        this.elementos = new Elemento[capacidad];
        this.capacidad = capacidad;
        this.cantidad = 0;
    }

    @Override
    public boolean esVacio() {
        return cantidad == 0;
    }

    public boolean esLleno() {
        return cantidad == capacidad;
    }

    // Auxiliar interno: busca la posicion de la clave recorriendo el arreglo, o -1 si no existe
    private int claveAIndice(Object clave) {
        int i = cantidad - 1;
        while (i >= 0 && !elementos[i].clave.equals(clave)) {
            i--;
        }
        return i;
    }

    @Override
    public boolean existeClave(Object clave) {
        return claveAIndice(clave) != -1;
    }

    @Override
    public void definir(Object clave, Object valor) {
        int posicion = claveAIndice(clave);
        if (posicion == -1) {
            if (esLleno()) {
                throw new RuntimeException("El diccionario se encuentra lleno");
            }
            posicion = cantidad;
            elementos[posicion] = new Elemento();
            elementos[posicion].clave = clave;
            cantidad++;
        }
        elementos[posicion].valor = valor;
    }

    @Override
    public void eliminar(Object clave) {
        int posicion = claveAIndice(clave);
        if (posicion == -1) {
            throw new RuntimeException("eliminar(): la clave no existe -> " + clave);
        }
        elementos[posicion] = elementos[cantidad - 1]; // se reemplaza por el ultimo (no hay orden que preservar)
        elementos[cantidad - 1] = null;
        cantidad--;
    }

    @Override
    public Object obtener(Object clave) {
        int posicion = claveAIndice(clave);
        if (posicion == -1) {
            throw new RuntimeException("obtener(): la clave no existe -> " + clave);
        }
        return elementos[posicion].valor;
    }

    @Override
    public Object[] claves() {
        Object[] c = new Object[cantidad];
        for (int i = 0; i < cantidad; i++) {
            c[i] = elementos[i].clave;
        }
        return c;
    }

    @Override
    public int cantidadClaves() {
        return cantidad;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("{ ");
        for (int i = 0; i < cantidad; i++) {
            sb.append(elementos[i].clave).append("=").append(elementos[i].valor).append(" ");
        }
        sb.append("}");
        return sb.toString();
    }
}

public interface ColaTDA {
    void crear();
    void encolar(int x);
    void desencolar();
    int frente();
    boolean esVacia();
}
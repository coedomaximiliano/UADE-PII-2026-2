public interface PilaTDA {
    void crear();
    void apilar(int x);
    void desapilar();
    int tope();
    boolean esVacia();
}
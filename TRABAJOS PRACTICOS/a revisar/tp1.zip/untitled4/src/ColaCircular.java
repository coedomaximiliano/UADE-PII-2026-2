public class ColaCircular implements ColaTDA {
    private int[] arreglo;
    private int frente;
    private int fin;
    private int cant;
    private static final int CANT_MAX = 1000;

    @Override
    public void crear() {
        arreglo = new int[CANT_MAX];
        frente = 0;
        fin = 0;
        cant = 0;
    }

    @Override
    public void encolar(int x) {
        arreglo[fin] = x;
        fin = (fin + 1) % CANT_MAX;
        cant++;
    }

    @Override
    public void desencolar() {
        frente = (frente + 1) % CANT_MAX;
        cant--;
    }

    @Override
    public int frente() {
        return arreglo[frente];
    }

    @Override
    public boolean esVacia() {
        return (cant == 0);
    }
}
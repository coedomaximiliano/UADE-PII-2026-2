public class MetodosPila {

    public static PilaTDA pasarPila(PilaTDA origen) {
        PilaTDA aux = new PilaVarianteA();
        aux.crear();
        while (!origen.esVacia()) {
            aux.apilar(origen.tope());
            origen.desapilar();
        }
        PilaTDA destino = new PilaVarianteA();
        destino.crear();
        while (!aux.esVacia()) {
            destino.apilar(aux.tope());
            aux.desapilar();
        }
        return destino;
    }

    public static PilaTDA copiarPila(PilaTDA p) {
        PilaTDA aux = new PilaVarianteA();
        aux.crear();
        PilaTDA copia = new PilaVarianteA();
        copia.crear();
        while (!p.esVacia()) {
            aux.apilar(p.tope());
            p.desapilar();
        }
        while (!aux.esVacia()) {
            int elem = aux.tope();
            p.apilar(elem);
            copia.apilar(elem);
            aux.desapilar();
        }
        return copia;
    }

    public static PilaTDA invertirPila(PilaTDA p) {
        PilaTDA copia = copiarPila(p);
        PilaTDA resultado = new PilaVarianteA();
        resultado.crear();
        invertirRecursivo(copia, resultado);
        return resultado;
    }

    private static void invertirRecursivo(PilaTDA origen, PilaTDA destino) {
        if (origen.esVacia()) {
            return;
        }
        int elem = origen.tope();
        origen.desapilar();
        destino.apilar(elem);
        invertirRecursivo(origen, destino);
    }

    public static boolean masDeUnaOcurrencia(PilaTDA p) {
        PilaTDA copia = copiarPila(p);
        boolean repetido = false;

        while (!copia.esVacia() && !repetido) {
            int actual = copia.tope();
            copia.desapilar();

            PilaTDA aux = copiarPila(copia);
            while (!aux.esVacia()) {
                if (aux.tope() == actual) {
                    repetido = true;
                    break;
                }
                aux.desapilar();
            }
        }
        return repetido;
    }

    public static PilaTDA eliminarImpares(PilaTDA p) {
        PilaTDA copia = copiarPila(p);
        PilaTDA auxPares = new PilaVarianteA();
        auxPares.crear();

        while (!copia.esVacia()) {
            int elem = copia.tope();
            copia.desapilar();
            if (elem % 2 == 0) {
                auxPares.apilar(elem);
            }
        }
        return pasarPila(auxPares);
    }
}
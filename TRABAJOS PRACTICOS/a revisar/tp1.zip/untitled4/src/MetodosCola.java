public class MetodosCola {

    public static ColaTDA copiarCola(ColaTDA c) {
        ColaTDA aux = new ColaCircular();
        aux.crear();
        ColaTDA copia = new ColaCircular();
        copia.crear();
        while (!c.esVacia()) {
            int elem = c.frente();
            aux.encolar(elem);
            copia.encolar(elem);
            c.desencolar();
        }
        while (!aux.esVacia()) {
            c.encolar(aux.frente());
            aux.desencolar();
        }
        return copia;
    }

    public static ColaTDA pasarCola(ColaTDA origen) {
        ColaTDA destino = new ColaCircular();
        destino.crear();
        while (!origen.esVacia()) {
            destino.encolar(origen.frente());
            origen.desencolar();
        }
        return destino;
    }

    public static ColaTDA invertirColaConPila(ColaTDA c) {
        PilaTDA auxPila = new PilaVarianteA();
        auxPila.crear();
        ColaTDA copia = copiarCola(c);

        while (!copia.esVacia()) {
            auxPila.apilar(copia.frente());
            copia.desencolar();
        }

        ColaTDA invertida = new ColaCircular();
        invertida.crear();
        while (!auxPila.esVacia()) {
            invertida.encolar(auxPila.tope());
            auxPila.desapilar();
        }
        return invertida;
    }

    public static ColaTDA invertirColaSinPila(ColaTDA c) {
        ColaTDA copia = copiarCola(c);
        ColaTDA invertida = new ColaCircular();
        invertida.crear();
        recursivoInvertir(copia, invertida);
        return invertida;
    }

    private static void recursivoInvertir(ColaTDA origen, ColaTDA destino) {
        if (origen.esVacia()) {
            return;
        }
        int elem = origen.frente();
        origen.desencolar();
        recursivoInvertir(origen, destino);
        destino.encolar(elem);
    }

    public static boolean finalCoincide(ColaTDA c1, ColaTDA c2, int k) {
        ColaTDA rev1 = invertirColaSinPila(c1);
        ColaTDA rev2 = invertirColaSinPila(c2);

        boolean coinciden = true;
        int cont = 0;

        while (!rev1.esVacia() && !rev2.esVacia() && cont < k) {
            if (rev1.frente() != rev2.frente()) {
                coinciden = false;
                break;
            }
            rev1.desencolar();
            rev2.desencolar();
            cont++;
        }

        if (cont < k) coinciden = false;
        return coinciden;
    }
}
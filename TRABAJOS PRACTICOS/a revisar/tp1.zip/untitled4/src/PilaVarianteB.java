public class PilaVarianteB implements PilaTDA {
    private int[] arreglo;
    private int cant;
    private static final int CANT_MAX = 1000;

    @Override
    public void crear() {
        arreglo = new int[CANT_MAX];
        cant = 0;
    }

    @Override
    public void apilar(int x) {
        for (int i = cant; i > 0; i--) {
            arreglo[i] = arreglo[i - 1];
        }
        arreglo[0] = x;
        cant++;
    }

    @Override
    public void desapilar() {
        for (int i = 0; i < cant - 1; i++) {
            arreglo[i] = arreglo[i + 1];
        }
        cant--;
    }

    @Override
    public int tope() {
        return arreglo[0];
    }

    @Override
    public boolean esVacia() {
        return (cant == 0);
    }
}
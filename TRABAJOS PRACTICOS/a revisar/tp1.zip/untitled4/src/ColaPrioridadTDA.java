public interface ColaPrioridadTDA {
    void crear();
    void insertar(int elem, int prio);
    int extraerMax();
    int verMax();
    int prioridadMax();
    boolean esVacia();
}
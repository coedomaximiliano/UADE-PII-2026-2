public class Main {
    public static void main(String[] args) {
        System.out.println("=== PRUEBAS TDA PILA ===");
        PilaTDA p = new PilaVarianteA();
        p.crear();
        p.apilar(1);
        p.apilar(2);
        p.apilar(3);
        p.apilar(2);

        System.out.println("Pila original tiene repetidos: " + MetodosPila.masDeUnaOcurrencia(p));

        PilaTDA pPares = MetodosPila.eliminarImpares(p);
        System.out.print("Pila solo con pares: ");
        while (!pPares.esVacia()) {
            System.out.print(pPares.tope() + " ");
            pPares.desapilar();
        }
        System.out.println("\n");

        System.out.println("=== PRUEBAS TDA COLA ===");
        ColaTDA c1 = new ColaCircular();
        c1.crear();
        c1.encolar(10);
        c1.encolar(20);
        c1.encolar(30);

        ColaTDA cInvertida = MetodosCola.invertirColaSinPila(c1);
        System.out.print("Cola invertida: ");
        while (!cInvertida.esVacia()) {
            System.out.print(cInvertida.frente() + " ");
            cInvertida.desencolar();
        }
        System.out.println("\n");

        System.out.println("=== PRUEBAS TDA COLA CON PRIORIDAD ===");
        ColaPrioridadTDA cp = new ColaPrioridadOrdenada();
        cp.crear();
        cp.insertar(100, 2);
        cp.insertar(50, 3);
        cp.insertar(200, 4);

        int sumaPares = MetodosColaPrioridad.sumarValoresPrioridadPar(cp);
        System.out.println("Suma de elementos con prioridad par: " + sumaPares);
    }
}
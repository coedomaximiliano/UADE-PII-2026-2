public class PilaVarianteA implements PilaTDA {
    private int[] arreglo;
    private int topeIndex;
    private static final int CANT_MAX = 1000;

    @Override
    public void crear() {
        arreglo = new int[CANT_MAX];
        topeIndex = 0;
    }

    @Override
    public void apilar(int x) {
        arreglo[topeIndex] = x;
        topeIndex++;
    }

    @Override
    public void desapilar() {
        topeIndex--;
    }

    @Override
    public int tope() {
        return arreglo[topeIndex - 1];
    }

    @Override
    public boolean esVacia() {
        return (topeIndex == 0);
    }
}
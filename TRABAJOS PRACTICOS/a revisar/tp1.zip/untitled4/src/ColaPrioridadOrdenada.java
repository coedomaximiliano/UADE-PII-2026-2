public class ColaPrioridadOrdenada implements ColaPrioridadTDA {
    private class Elemento {
        int valor;
        int prioridad;
    }

    private Elemento[] elementos;
    private int cant;
    private static final int CANT_MAX = 1000;

    @Override
    public void crear() {
        elementos = new Elemento[CANT_MAX];
        cant = 0;
    }

    @Override
    public void insertar(int elem, int prio) {
        Elemento nuevo = new Elemento();
        nuevo.valor = elem;
        nuevo.prioridad = prio;

        int i = cant - 1;
        while (i >= 0 && elementos[i].prioridad < prio) {
            elementos[i + 1] = elementos[i];
            i--;
        }
        elementos[i + 1] = nuevo;
        cant++;
    }

    @Override
    public int extraerMax() {
        int val = elementos[0].valor;
        for (int i = 0; i < cant - 1; i++) {
            elementos[i] = elementos[i + 1];
        }
        cant--;
        return val;
    }

    @Override
    public int verMax() {
        return elementos[0].valor;
    }

    @Override
    public int prioridadMax() {
        return elementos[0].prioridad;
    }

    @Override
    public boolean esVacia() {
        return (cant == 0);
    }
}
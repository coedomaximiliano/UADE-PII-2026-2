public class MetodosColaPrioridad {

    public static ColaPrioridadTDA combinar(ColaPrioridadTDA cp1, ColaPrioridadTDA cp2) {
        ColaPrioridadTDA res = new ColaPrioridadOrdenada();
        res.crear();

        while (!cp1.esVacia()) {
            int prio = cp1.prioridadMax();
            int elem = cp1.extraerMax();
            res.insertar(elem, prio);
        }

        while (!cp2.esVacia()) {
            int prio = cp2.prioridadMax();
            int elem = cp2.extraerMax();
            res.insertar(elem, prio);
        }

        return res;
    }

    public static ColaTDA invertirColaConColaPrioridad(ColaTDA c) {
        ColaPrioridadTDA cpAux = new ColaPrioridadOrdenada();
        cpAux.crear();

        ColaTDA copia = MetodosCola.copiarCola(c);
        int prioridadAsignada = 1000000;

        while (!copia.esVacia()) {
            cpAux.insertar(copia.frente(), prioridadAsignada);
            prioridadAsignada--;
            copia.desencolar();
        }

        ColaTDA invertida = new ColaCircular();
        invertida.crear();

        while (!cpAux.esVacia()) {
            invertida.encolar(cpAux.extraerMax());
        }

        return invertida;
    }

    public static int sumarValoresPrioridadPar(ColaPrioridadTDA cp) {
        ColaPrioridadTDA aux = new ColaPrioridadOrdenada();
        aux.crear();
        int suma = 0;

        while (!cp.esVacia()) {
            int prio = cp.prioridadMax();
            int elem = cp.extraerMax();

            if (prio % 2 == 0) {
                suma += elem;
            }
            aux.insertar(elem, prio);
        }

        while (!aux.esVacia()) {
            cp.insertar(aux.extraerMax(), aux.prioridadMax());
        }

        return suma;
    }
}
package tp2;

public class ComparacionTest {

    public static void main(String[] args) {
        int[] tamanios = {1000, 10000, 100000};

        System.out.println("MEDIDAS EMPIRICAS (en nanosegundos)");
        System.out.println("n\tDef_Estática\tDef_Dinámica\tGet_Estática\tGet_Dinámica");

        for (int n : tamanios) {
            long tiempoDefEstatica = medirDefinirEstatica(n);
            long tiempoDefDinamica = medirDefinirDinamica(n);

            long tiempoGetEstatica = medirObtenerEstatica(n);
            long tiempoGetDinamica = medirObtenerDinamica(n);

            System.out.println(n + "\t" + tiempoDefEstatica + "\t\t" + tiempoDefDinamica + "\t\t" + tiempoGetEstatica + "\t\t" + tiempoGetDinamica);
        }
    }

    private static long medirDefinirEstatica(int n) {
        DiccionarioEstatico dWarmup = new DiccionarioEstatico(n + 10);
        for (int i = 0; i < 100; i++) {
            dWarmup.definir("key_w_" + i, "val");
        }

        long mejorTiempo = Long.MAX_VALUE;
        for (int rep = 0; rep < 5; rep++) {
            DiccionarioEstatico d = new DiccionarioEstatico(n + 10);
            long inicio = System.nanoTime();
            for (int i = 0; i < n; i++) {
                d.definir("k_" + i, i);
            }
            long fin = System.nanoTime();
            long duracion = fin - inicio;
            if (duracion < mejorTiempo) {
                mejorTiempo = duracion;
            }
        }
        return mejorTiempo;
    }

    private static long medirDefinirDinamica(int n) {
        DiccionarioDinamico dWarmup = new DiccionarioDinamico();
        for (int i = 0; i < 100; i++) {
            dWarmup.definir("key_w_" + i, "val");
        }

        long mejorTiempo = Long.MAX_VALUE;
        for (int rep = 0; rep < 5; rep++) {
            DiccionarioDinamico d = new DiccionarioDinamico();
            long inicio = System.nanoTime();
            for (int i = 0; i < n; i++) {
                d.definir("k_" + i, i);
            }
            long fin = System.nanoTime();
            long duracion = fin - inicio;
            if (duracion < mejorTiempo) {
                mejorTiempo = duracion;
            }
        }
        return mejorTiempo;
    }

    private static long medirObtenerEstatica(int n) {
        DiccionarioEstatico d = new DiccionarioEstatico(n + 10);
        for (int i = 0; i < n; i++) {
            d.definir("k_" + i, i);
        }

        long mejorTiempo = Long.MAX_VALUE;
        for (int rep = 0; rep < 5; rep++) {
            long inicio = System.nanoTime();
            d.obtener("k_" + (n / 2));
            long fin = System.nanoTime();
            long duracion = fin - inicio;
            if (duracion < mejorTiempo) {
                mejorTiempo = duracion;
            }
        }
        return mejorTiempo;
    }

    private static long medirObtenerDinamica(int n) {
        DiccionarioDinamico d = new DiccionarioDinamico();
        for (int i = 0; i < n; i++) {
            d.definir("k_" + i, i);
        }

        long mejorTiempo = Long.MAX_VALUE;
        for (int rep = 0; rep < 5; rep++) {
            long inicio = System.nanoTime();
            d.obtener("k_" + (n / 2));
            long fin = System.nanoTime();
            long duracion = fin - inicio;
            if (duracion < mejorTiempo) {
                mejorTiempo = duracion;
            }
        }
        return mejorTiempo;
    }
}
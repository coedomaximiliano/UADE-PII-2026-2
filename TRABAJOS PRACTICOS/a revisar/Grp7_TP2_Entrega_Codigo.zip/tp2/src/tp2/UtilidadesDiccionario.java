package tp2;

public class UtilidadesDiccionario {

    // 1. combinarDiccionarios(d1, d2)
    // Devuelve un nuevo diccionario con las claves de ambos; si esta en los dos, gana el valor de d2. d1 y d2 no se modifican.
	
    public static DiccionarioDinamico combinarDiccionarios(DiccionarioDinamico d1, DiccionarioDinamico d2) {
        DiccionarioDinamico resultado = new DiccionarioDinamico();
        
        // Copiamos las claves de d1
        
        Object[] claves1 = (Object[]) d1.claves();
        for (int i = 0; i < claves1.length; i++) {
            resultado.definir(claves1[i], d1.obtener(claves1[i]));
        }
        
        // Copiamos las claves de d2 (si se repiten, definir() actualiza con el valor de d2)
        
        Object[] claves2 = (Object[]) d2.claves();
        for (int i = 0; i < claves2.length; i++) {
            resultado.definir(claves2[i], d2.obtener(claves2[i]));
        }
        
        return resultado;
    }

    // 2. invertir(d)
    // Devuelve un nuevo diccionario donde las claves pasan a ser valores y los valores claves (valores originales unicos). d no se modifica.
    
    public static DiccionarioDinamico invertir(DiccionarioDinamico d) {
        DiccionarioDinamico invertido = new DiccionarioDinamico();
        
        Object[] misClaves = (Object[]) d.claves();
        for (int i = 0; i < misClaves.length; i++) {
            Object claveOriginal = misClaves[i];
            Object valorOriginal = d.obtener(claveOriginal);
            
            // Invertimos relacion el valor pasa a ser clave y la clave pasa a ser valor
            invertido.definir(valorOriginal, claveOriginal);
        }
        
        return invertido;
    }

    
 // 3. contarValoresMayoresA(d, tope)
    // Cuenta cuantos pares de d tienen valor numérico estrictamente mayor a tope. d no se modifica.
    
    public static int contarValoresMayoresA(DiccionarioDinamico d, int tope) {
        int contador = 0;
        Object[] misClaves = (Object[]) d.claves();
        for (int i = 0; i < misClaves.length; i++) {
            int valor = (int) d.obtener(misClaves[i]);
            if (valor > tope) {
                contador++;
            }
        }
        return contador;
    }

    // 4. clavesOrdenadas(d)
    // Devuelve un arreglo con las claves de d ordenadas alfabeticamente asumiendo tipo texto. d no se modifica.
    
    
    public static Object[] clavesOrdenadas(DiccionarioDinamico d) {
        Object[] misClaves = (Object[]) d.claves();
        
        
        // Ordenamiento simple por método de burbujeo 
        for (int i = 0; i < misClaves.length - 1; i++) {
            for (int j = 0; j < misClaves.length - 1 - i; j++) {
                String c1 = (String) misClaves[j];
                String c2 = (String) misClaves[j + 1];
                if (c1.compareTo(c2) > 0) {
                    Object aux = misClaves[j];
                    misClaves[j] = misClaves[j + 1];
                    misClaves[j + 1] = aux;
                }
            }
        }
        
        return misClaves;
    }
}
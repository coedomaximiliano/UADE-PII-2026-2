package tp2;

public class DiccionarioDinamico {
    private NodoDiccionario cabeza;
    private int cantidad;

    public DiccionarioDinamico() {
        this.cabeza = null;
        this.cantidad = 0;
    }

    private NodoDiccionario buscarNodo(Object clave) {
        NodoDiccionario actual = cabeza;
        while (actual != null) {
            if (actual.clave.equals(clave)) {
                return actual;
            }
            actual = actual.siguiente;
        }
        return null;
    }

    public void definir(Object clave, Object valor) {
        NodoDiccionario existente = buscarNodo(clave);
        if (existente != null) {
            existente.valor = valor;
        } else {
            NodoDiccionario nuevo = new NodoDiccionario(clave, valor);
            nuevo.siguiente = cabeza;
            cabeza = nuevo;
            cantidad++;
        }
    }

    public Object obtener(Object clave) {
        NodoDiccionario nodo = buscarNodo(clave);
        if (nodo == null) {
            throw new RuntimeException("obtener(): la clave no existe -> " + clave);
        }
        return nodo.valor;
    }

    public void eliminar(Object clave) {
        NodoDiccionario actual = cabeza, anterior = null;
        while (actual != null) {
            if (actual.clave.equals(clave)) {
                if (anterior == null) {
                    cabeza = actual.siguiente;
                } else {
                    anterior.siguiente = actual.siguiente;
                }
                cantidad--;
                return;
            }
            anterior = actual;
            actual = actual.siguiente;
        }
        throw new RuntimeException("eliminar(): la clave no existe");
    }

    public boolean existeClave(Object clave) {
        return buscarNodo(clave) != null;
    }

    public boolean esVacio() {
        return cabeza == null;
    }

    public int cantidadClaves() {
        return cantidad;
    }

    public Object[] claves() {
        Object[] resultado = new Object[cantidad];
        NodoDiccionario actual = cabeza;
        int i = 0;
        while (actual != null) {
            resultado[i++] = actual.clave;
            actual = actual.siguiente;
        }
        return resultado;
    }
}

class NodoDiccionario {
    Object clave;
    Object valor;
    NodoDiccionario siguiente;

    public NodoDiccionario(Object clave, Object valor) {
        this.clave = clave;
        this.valor = valor;
        this.siguiente = null;
    }
}
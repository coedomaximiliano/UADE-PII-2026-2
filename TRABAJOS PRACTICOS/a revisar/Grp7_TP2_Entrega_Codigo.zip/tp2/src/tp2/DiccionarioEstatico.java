package tp2;

public class DiccionarioEstatico {
    private Object[] clavesArr;
    private Object[] valoresArr;
    private int cantidad;
    private int capacidad;

    public DiccionarioEstatico(int capacidad) {
        this.capacidad = capacidad;
        this.clavesArr = new Object[capacidad];
        this.valoresArr = new Object[capacidad];
        this.cantidad = 0;
    }

    private int buscarIndice(Object clave) {
        for (int i = 0; i < cantidad; i++) {
            if (clavesArr[i].equals(clave)) {
                return i;
            }
        }
        return -1;
    }

    public void definir(Object clave, Object valor) {
        int idx = buscarIndice(clave);
        if (idx != -1) {
            valoresArr[idx] = valor;
        } else {
            if (cantidad >= capacidad) {
                throw new RuntimeException("Diccionario estático lleno");
            }
            clavesArr[cantidad] = clave;
            valoresArr[cantidad] = valor;
            cantidad++;
        }
    }

    public Object obtener(Object clave) {
        int idx = buscarIndice(clave);
        if (idx == -1) {
            throw new RuntimeException("obtener(): la clave no existe -> " + clave);
        }
        return valoresArr[idx];
    }

    public void eliminar(Object clave) {
        int idx = buscarIndice(clave);
        if (idx != -1) {
            clavesArr[idx] = clavesArr[cantidad - 1];
            valoresArr[idx] = valoresArr[cantidad - 1];
            clavesArr[cantidad - 1] = null;
            valoresArr[cantidad - 1] = null;
            cantidad--;
        } else {
            throw new RuntimeException("eliminar(): la clave no existe");
        }
    }

    public boolean existeClave(Object clave) {
        return buscarIndice(clave) != -1;
    }

    public boolean esVacio() {
        return cantidad == 0;
    }

    public int cantidadClaves() {
        return cantidad;
    }

    public Object[] claves() {
        Object[] resultado = new Object[cantidad];
        for (int i = 0; i < cantidad; i++) {
            resultado[i] = clavesArr[i];
        }
        return resultado;
    }
}
public class DiccionarioDinamico implements Diccionario {
    private NodoDiccionario primero;
    private int cantidad;

    public DiccionarioDinamico() {
        this.primero = null;
        this.cantidad = 0;
    }

    @Override
    public void definir(Object clave, Object valor) {
        NodoDiccionario actual = primero;
        while (actual != null) {
            if (actual.clave.equals(clave)) {
                actual.valor = valor; // Clave existente: actualiza valor
                return;
            }
            actual = actual.siguiente;
        }
        // Clave nueva: inserción al principio
        this.primero = new NodoDiccionario(clave, valor, this.primero);
        this.cantidad++;
    }

    @Override
    public Object obtener(Object clave) {
        NodoDiccionario actual = primero;
        while (actual != null) {
            if (actual.clave.equals(clave)) {
                return actual.valor;
            }
            actual = actual.siguiente;
        }
        throw new IllegalArgumentException("La clave no existe en el diccionario.");
    }

    @Override
    public void eliminar(Object clave) {
        if (primero == null) return;

        if (primero.clave.equals(clave)) {
            primero = primero.siguiente;
            cantidad--;
            return;
        }

        NodoDiccionario actual = primero;
        while (actual.siguiente != null && !actual.siguiente.clave.equals(clave)) {
            actual = actual.siguiente;
        }

        if (actual.siguiente != null) {
            actual.siguiente = actual.siguiente.siguiente;
            cantidad--;
        }
    }

    @Override
    public boolean existeClave(Object clave) {
        NodoDiccionario actual = primero;
        while (actual != null) {
            if (actual.clave.equals(clave)) {
                return true;
            }
            actual = actual.siguiente;
        }
        return false;
    }

    @Override
    public boolean esVacio() {
        return this.cantidad == 0;
    }

    @Override
    public int cantidadClaves() {
        return this.cantidad;
    }

    @Override
    public ListaDinamica claves() {
        ListaDinamica listaClaves = new ListaDinamica();
        NodoDiccionario actual = primero;
        while (actual != null) {
            listaClaves.agregarAlFinal(actual.clave);
            actual = actual.siguiente;
        }
        return listaClaves;
    }
}
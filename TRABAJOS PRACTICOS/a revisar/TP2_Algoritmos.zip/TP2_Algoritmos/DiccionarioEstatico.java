public class DiccionarioEstatico implements Diccionario {
    private Object[] claves;
    private Object[] valores;
    private int cantidad;

    public DiccionarioEstatico(int capacidad) {
        this.claves = new Object[capacidad];
        this.valores = new Object[capacidad];
        this.cantidad = 0;
    }

    @Override
    public void definir(Object clave, Object valor) {
        for (int i = 0; i < cantidad; i++) {
            if (claves[i].equals(clave)) {
                valores[i] = valor;
                return;
            }
        }
        if (cantidad >= claves.length) {
            throw new IllegalStateException("Capacidad máxima del arreglo alcanzada.");
        }
        claves[cantidad] = clave;
        valores[cantidad] = valor;
        cantidad++;
    }

    @Override
    public Object obtener(Object clave) {
        for (int i = 0; i < cantidad; i++) {
            if (claves[i].equals(clave)) {
                return valores[i];
            }
        }
        throw new IllegalArgumentException("La clave no existe en el diccionario.");
    }

    @Override
    public void eliminar(Object clave) {
        for (int i = 0; i < cantidad; i++) {
            if (claves[i].equals(clave)) {
                // Reemplazamos por el último elemento para mantener borrado físico en O(1)
                claves[i] = claves[cantidad - 1];
                valores[i] = valores[cantidad - 1];
                claves[cantidad - 1] = null;
                valores[cantidad - 1] = null;
                cantidad--;
                return;
            }
        }
    }

    @Override
    public boolean existeClave(Object clave) {
        for (int i = 0; i < cantidad; i++) {
            if (claves[i].equals(clave)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean esVacio() {
        return this.cantidad == 0;
    }

    @Override
    public int cantidadClaves() {
        return this.cantidad;
    }

    @Override
    public ListaDinamica claves() {
        ListaDinamica listaClaves = new ListaDinamica();
        for (int i = 0; i < cantidad; i++) {
            listaClaves.agregarAlFinal(claves[i]);
        }
        return listaClaves;
    }
}
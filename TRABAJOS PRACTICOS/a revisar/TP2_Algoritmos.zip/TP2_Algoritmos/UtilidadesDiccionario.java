public class UtilidadesDiccionario {

    // 1. combinarDiccionarios
    public static Diccionario combinarDiccionarios(Diccionario d1, Diccionario d2) {
        Diccionario res = new DiccionarioDinamico();

        ListaDinamica claves1 = d1.claves();
        for (int i = 0; i < claves1.tamanio(); i++) {
            Object k = claves1.obtener(i);
            Object v = d1.obtener(k);
            res.definir(k, v);
        }

        ListaDinamica claves2 = d2.claves();
        for (int i = 0; i < claves2.tamanio(); i++) {
            Object k = claves2.obtener(i);
            Object v = d2.obtener(k);
            res.definir(k, v);
        }

        return res;
    }

    // 2. invertir
    public static Diccionario invertir(Diccionario d) {
        Diccionario invertido = new DiccionarioDinamico();
        ListaDinamica listaClaves = d.claves();

        for (int i = 0; i < listaClaves.tamanio(); i++) {
            Object k = listaClaves.obtener(i);
            Object v = d.obtener(k);
            invertido.definir(v, k);
        }
        return invertido;
    }

    // 3. contarValoresMayoresA
    public static int contarValoresMayoresA(Diccionario d, int umbral) {
        int contador = 0;
        ListaDinamica listaClaves = d.claves();

        for (int i = 0; i < listaClaves.tamanio(); i++) {
            Object k = listaClaves.obtener(i);
            Number val = (Number) d.obtener(k);
            if (val.intValue() > umbral) {
                contador++;
            }
        }
        return contador;
    }

    // 4. clavesOrdenadas (Selection Sort)
    public static ListaDinamica clavesOrdenadas(Diccionario d) {
        ListaDinamica listaOriginal = d.claves();
        int n = listaOriginal.tamanio();

        String[] arreglo = new String[n];
        for (int i = 0; i < n; i++) {
            arreglo[i] = (String) listaOriginal.obtener(i);
        }

        for (int i = 0; i < n - 1; i++) {
            int minIdx = i;
            for (int j = i + 1; j < n; j++) {
                if (arreglo[j].compareTo(arreglo[minIdx]) < 0) {
                    minIdx = j;
                }
            }
            String temp = arreglo[minIdx];
            arreglo[minIdx] = arreglo[i];
            arreglo[i] = temp;
        }

        ListaDinamica ordenada = new ListaDinamica();
        for (int i = 0; i < n; i++) {
            ordenada.agregarAlFinal(arreglo[i]);
        }
        return ordenada;
    }
}
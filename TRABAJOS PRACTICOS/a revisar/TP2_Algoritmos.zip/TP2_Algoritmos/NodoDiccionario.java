public class NodoDiccionario {
    public Object clave;
    public Object valor;
    public NodoDiccionario siguiente;

    public NodoDiccionario(Object clave, Object valor, NodoDiccionario siguiente) {
        this.clave = clave;
        this.valor = valor;
        this.siguiente = siguiente;
    }
}
public class Main {
    private static final int WARMUP_ROUNDS = 5;
    private static final int REPETICIONES = 15;

    public static void main(String[] args) {
        int[] tamanos = {1000, 10000, 100000};

        System.out.println("Ejecutando mediciones empíricas...\n");
        System.out.printf("%-8s | %-18s | %-18s | %-18s | %-18s%n",
                "n", "def() - Estática", "def() - Dinámica", "obt() - Estática", "obt() - Dinámica");
        System.out.println("----------------------------------------------------------------------------------------");

        for (int n : tamanos) {
            // 1. definir() Estática
            long tDefEst = medirNanos(() -> {
                DiccionarioEstatico d = new DiccionarioEstatico(n + 1);
                for (int i = 0; i < n; i++) d.definir("k" + i, i);
                return d;
            }, d -> d.definir("clave_nueva", -1));

            // 2. definir() Dinámica
            long tDefDin = medirNanos(() -> {
                DiccionarioDinamico d = new DiccionarioDinamico();
                for (int i = 0; i < n; i++) d.definir("k" + i, i);
                return d;
            }, d -> d.definir("clave_nueva", -1));

            // 3. obtener() Estática (peor caso: última posición en el arreglo)
            long tObtEst = medirNanos(() -> {
                DiccionarioEstatico d = new DiccionarioEstatico(n);
                for (int i = 0; i < n; i++) d.definir("k" + i, i);
                return d;
            }, d -> d.obtener("k" + (n - 1)));

            // 4. obtener() Dinámica (peor caso: fondo de la cadena enlazada)
            long tObtDin = medirNanos(() -> {
                DiccionarioDinamico d = new DiccionarioDinamico();
                for (int i = 0; i < n; i++) d.definir("k" + i, i);
                return d;
            }, d -> d.obtener("k0"));

            System.out.printf("%-8d | %-15d ns | %-15d ns | %-15d ns | %-15d ns%n",
                    n, tDefEst, tDefDin, tObtEst, tObtDin);
        }
    }

    /**
     * Técnica medirNanos() vista en clase:
     * - Configura la estructura previa en cada intento sin medir el armado.
     * - Ejecuta rondas de calentamiento (warmup) para la JVM / JIT.
     * - Retorna el mejor tiempo (mínimo) en nanosegundos tras varias repeticiones.
     */
    public static <T> long medirNanos(java.util.function.Supplier<T> inicializador, java.util.function.Consumer<T> operacion) {
        long mejorTiempo = Long.MAX_VALUE;

        for (int r = 0; r < WARMUP_ROUNDS + REPETICIONES; r++) {
            T estructura = inicializador.get();

            long inicio = System.nanoTime();
            operacion.accept(estructura);
            long fin = System.nanoTime();

            long duracion = fin - inicio;

            // Se descartan las rondas de warmup y se conserva el mínimo
            if (r >= WARMUP_ROUNDS) {
                mejorTiempo = Math.min(mejorTiempo, duracion);
            }
        }

        return mejorTiempo;
    }
}
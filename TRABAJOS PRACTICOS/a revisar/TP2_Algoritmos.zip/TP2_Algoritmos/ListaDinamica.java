public class ListaDinamica {
    private class NodoLista {
        Object dato;
        NodoLista sig;

        NodoLista(Object d, NodoLista s) {
            this.dato = d;
            this.sig = s;
        }
    }

    private NodoLista primero = null;
    private NodoLista ultimo = null;
    private int cant = 0;

    public void agregarAlFinal(Object dato) {
        NodoLista nuevo = new NodoLista(dato, null);
        if (primero == null) {
            primero = ultimo = nuevo;
        } else {
            ultimo.sig = nuevo;
            ultimo = nuevo;
        }
        cant++;
    }

    public int tamanio() {
        return cant;
    }

    public Object obtener(int indice) {
        if (indice < 0 || indice >= cant) {
            throw new IndexOutOfBoundsException("Índice fuera de rango: " + indice);
        }
        NodoLista actual = primero;
        for (int i = 0; i < indice; i++) {
            actual = actual.sig;
        }
        return actual.dato;
    }
}